package dev.rec877.north

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** /2 のJSON成功応答は { "data": ... } */
@Serializable data class Envelope<T>(val data: T)

@Serializable
data class User(
    val id: String = "",
    val handle: String = "",
    val name: String = "",
    val bio: String? = null,
    val location: String? = null,
    val website: String? = null,
    val avatarUrl: String? = null,
    val headerUrl: String? = null,
    @SerialName("protected") val isProtected: Boolean = false,
    val verified: Boolean = false,
    val followerCount: Int = 0,
    val followingCount: Int = 0,
    val tweetCount: Int = 0,
    val createdAt: String? = null,
    val following: Boolean = false,
    val followedBy: Boolean = false,
    val blocking: Boolean = false,
    val muting: Boolean = false,
    /** プロフィール先頭に固定されているポスト。ユーザー詳細でのみ返る。 */
    val pinnedTweet: Post? = null,
    /** プロフィール・ポストの名前横に出す実績バッジ（最大5個）。表示順は displayOrder */
    val displayedBadges: List<DisplayedBadge> = emptyList(),
)

@Serializable
data class DisplayedBadge(val key: String, val awardedAt: String? = null, val displayOrder: Int? = null)

/** 表示するバッジ。ユーザー詳細に無いときは、固定ポストの投稿者（同じ本人）の情報を使う */
fun User.shownBadges(): List<DisplayedBadge> =
    (displayedBadges.ifEmpty { pinnedTweet?.author?.displayedBadges.orEmpty() })
        .sortedBy { it.displayOrder ?: Int.MAX_VALUE }
        .take(5)

@Serializable
data class Media(
    val id: String,
    /** PHOTO / GIF / VIDEO */
    val kind: String = "PHOTO",
    val url: String,
    val thumbnailUrl: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val altText: String? = null,
    val sensitive: Boolean = false,
    val status: String? = null,
    val errorMessage: String? = null,
    val durationMs: Long? = null,
    val warning: String? = null,
)

@Serializable
data class Post(
    val id: String,
    // 表示できないポストは本文などが返らないので、すべて既定値を持たせて落ちないようにする
    val text: String = "",
    val createdAt: String = "",
    val editedAt: String? = null,
    val author: User = User(),
    val conversationId: String? = null,
    val source: String? = null,
    val inReplyToId: String? = null,
    val inReplyToHandle: String? = null,
    /** 引用しているポスト（入れ子は1段まで） */
    val quoted: Post? = null,
    val retweetOf: Post? = null,
    val likeCount: Int = 0,
    val retweetCount: Int = 0,
    val replyCount: Int = 0,
    val quoteCount: Int = 0,
    val poll: Poll? = null,
    val media: List<Media> = emptyList(),
    val liked: Boolean = false,
    val retweeted: Boolean = false,
    val bookmarked: Boolean = false,
    /** 自分の固定ポストか。ポスト単体・一覧の「…」メニュー判定に使う。 */
    val pinned: Boolean = false,
    /** EVERYONE / FOLLOWING / MENTIONED */
    val replyPolicy: String = "EVERYONE",
    val unavailable: Boolean = false,
    val quotedUnavailable: Boolean = false,
    /** muted / blocked */
    val hiddenReason: String? = null,
    /** 編集できる状態か（編集ボタンの出し分けに使う。最終判定はサーバー） */
    val editEligible: Boolean = false,
    val editCount: Int = 0,
)

/** 投稿者(userId)のUserを f で書き換える。リポスト元・引用先の投稿者も対象 */
fun Post.withAuthorPatched(userId: String, f: (User) -> User): Post {
    val newAuthor = if (author.id == userId) f(author) else author
    return copy(
        author = newAuthor,
        retweetOf = retweetOf?.withAuthorPatched(userId, f),
        quoted = quoted?.withAuthorPatched(userId, f),
    )
}

/** 指定ユーザーの投稿（リポスト含む）を取り除く。引用先がそのユーザーなら引用不可表示にする */
fun Post.withoutAuthor(userId: String): Post? {
    if (author.id == userId || retweetOf?.author?.id == userId) return null
    return if (quoted?.author?.id == userId) copy(quoted = null, quotedUnavailable = true) else this
}

/** リストへの所属状態（GET /2/lists/memberships?handle=）。contains=そのアカウントが入っているか */
@Serializable data class ListMembership(
    val id: String,
    val name: String,
    @SerialName("private") val isPrivate: Boolean = false,
    val memberCount: Int = 0,
    val contains: Boolean = false,
)
@Serializable data class ListMembershipPage(val items: List<ListMembership> = emptyList())

/** 連投（POST /2/tweets/thread）の1件分。replyPolicy は先頭だけでなく各件に指定できる */
data class ThreadItem(
    val text: String,
    val mediaIds: List<String> = emptyList(),
    val poll: PollInput? = null,
    /** EVERYONE / FOLLOWING / MENTIONED */
    val replyPolicy: String = "EVERYONE",
)

@Serializable data class ThreadResult(val items: List<Post> = emptyList())

@Serializable data class PollOption(
    val id: String,
    val label: String,
    val position: Int = 0,
    val voteCount: Int = 0,
    val percent: Double? = null,
)

@Serializable data class Poll(
    val id: String,
    val endsAt: String,
    val ended: Boolean = false,
    val totalVotes: Int = 0,
    val viewerOptionId: String? = null,
    val options: List<PollOption> = emptyList(),
)

/** このポスト自身、リポスト元、引用先のうち id が一致するものに f を適用する */
fun Post.patched(id: String, f: (Post) -> Post): Post {
    var p = if (this.id == id) f(this) else this
    p.retweetOf?.let { if (it.id == id) p = p.copy(retweetOf = f(it)) }
    p.quoted?.let { if (it.id == id) p = p.copy(quoted = f(it)) }
    return p
}

/** 削除したポストを一覧から除き、引用先だけが削除された場合は引用不可表示へ置き換える。 */
fun Post.withoutDeleted(id: String): Post? {
    if (this.id == id || retweetOf?.id == id) return null
    return if (quoted?.id == id) copy(quoted = null, quotedUnavailable = true) else this
}

@Serializable data class PostPage(val items: List<Post>, val nextCursor: String? = null)

@Serializable data class BookmarkFolder(
    val id: String,
    val name: String,
    val color: String = "",
    val count: Int = 0,
    val createdAt: String? = null,
)
@Serializable data class BookmarkFolderPage(val items: List<BookmarkFolder> = emptyList())

/** フォロー中・フォロワー・いいねしたユーザーのページ */
@Serializable data class UserPage(val items: List<User>, val nextCursor: String? = null)

/** 検索前の画面で表示する、north サーバー集計のトレンド。 */
@Serializable data class Trend(val tag: String, val count: Int = 0, val isHashtag: Boolean = false)
@Serializable data class TrendPage(val items: List<Trend> = emptyList())

@Serializable data class NorthList(
    val id: String, val name: String, val description: String? = null,
    @SerialName("private") val isPrivate: Boolean = false, val memberCount: Int = 0, val followerCount: Int = 0,
    val owner: User = User(), val ownedByViewer: Boolean = false, val followedByViewer: Boolean = false,
)
@Serializable data class NorthLists(val items: List<NorthList> = emptyList(), val followed: List<NorthList> = emptyList(), val pinned: List<NorthList> = emptyList())

@Serializable data class CreatedPost(val id: String, val text: String = "")

/** 投稿作成時だけ使う投票の入力値。サーバー側は2〜4択、5分〜7日を受け付ける。 */
data class PollInput(val options: List<String>, val durationMinutes: Int = 1440)

@Serializable data class DraftItem(val text: String = "", val replyPolicy: String? = null, val media: List<Media> = emptyList())
@Serializable data class Draft(val id: String, val items: List<DraftItem> = emptyList(), val createdAt: String = "", val updatedAt: String = "")
@Serializable data class DraftPage(val items: List<Draft> = emptyList())

/** /2/tweets/{id}/conversation: 祖先（古い順）・本人・返信（最大10件ずつ、続きは nextCursor） */
@Serializable
data class Conversation(
    val ancestors: List<Post> = emptyList(),
    val tweet: Post,
    val replies: List<Post> = emptyList(),
    val nextCursor: String? = null,
)

// ---- 通知 ----
@Serializable
data class Notification(
    /** まとめた中で最も新しい通知のID */
    val id: String,
    /** FOLLOW / LIKE / RETWEET / QUOTE / REPLY / MENTION / POST */
    val kind: String = "",
    val actors: List<User> = emptyList(),
    val actorCount: Int = 0,
    val groupCount: Int = 1,
    val targetCount: Int = 0,
    /** groupCount が2以上のときと、FOLLOWのときは null */
    val tweet: Post? = null,
    val createdAt: String = "",
    val read: Boolean = true,
    /**
     * 実績の獲得など、APIの種別一覧にない通知のときの表示名（「会話のきっかけ」など）。
     * 受信したJSONから NorthApi が取り出して入れる（サーバーのJSONには含まれないフィールド）
     */
    @kotlinx.serialization.Transient val label: String? = null,
    /** 種別が不明な通知の生JSON。長押しでコピーして、項目名の確認に使える */
    @kotlinx.serialization.Transient val raw: String? = null,
) {
    /** 実績・バッジ・システム通知など、既知の種別以外 */
    val isSystem: Boolean get() = kind !in KNOWN_KINDS

    companion object {
        val KNOWN_KINDS = setOf("FOLLOW", "LIKE", "RETWEET", "QUOTE", "REPLY", "MENTION", "POST")
    }
}

@Serializable data class NotificationPage(val items: List<Notification>, val nextCursor: String? = null)
@Serializable data class UnreadCount(val count: Int = 0)
@Serializable data class MarkedRead(val marked: Int = 0)

// ---- OAuth（こちらは { "data": ... } で包まれない、RFC準拠のフラット形式）----
@Serializable
data class TokenResponse(
    @SerialName("access_token") val accessToken: String,
    @SerialName("refresh_token") val refreshToken: String,
    @SerialName("expires_in") val expiresIn: Int,
    val scope: String = "",
)

@Serializable data class OAuthError(val error: String)