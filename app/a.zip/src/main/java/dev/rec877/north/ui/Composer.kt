package dev.rec877.north.ui

import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.TextButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import coil3.compose.AsyncImage
import dev.rec877.north.User
import dev.rec877.north.PollInput
import dev.rec877.north.unsupportedMediaReason
import dev.rec877.north.ui.theme.North
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private const val MAX_MEDIA_ITEMS = 4
private const val MAX_WEIGHT = 280

internal fun replyPolicyLabel(policy: String): String = when (policy) {
    "FOLLOWING" -> "フォローしている人が返信できます"
    "MENTIONED" -> "メンションした人だけが返信できます"
    else -> "全員が返信できます"
}


/** 入力欄が配置された次のフレームでカーソルを置き、キーボードを出す。 */
@Composable
private fun AutoFocus(enabled: Boolean, focusRequester: FocusRequester) {
    val keyboard = LocalSoftwareKeyboardController.current
    LaunchedEffect(enabled) {
        if (!enabled) return@LaunchedEffect
        withFrameNanos { }
        runCatching { focusRequester.requestFocus() }
        keyboard?.show()
    }
}

/**
 * サイトの .composer を再現。下段にメディア追加ボタンと「ポストする」(白ピル)。
 * 画像・動画はAndroidのフォトピッカー（権限不要）で合計最大4件。送信時にアップロードしてから投稿する。
 */
@Composable
fun Composer(
    me: User?,
    loader: ImageLoader,
    posting: Boolean,
    onSubmit: (text: String, images: List<Uri>, onDone: () -> Unit) -> Unit,
    /** 画像サムネイルの下に差し込む内容（引用するポストのカードなど） */
    extra: (@Composable () -> Unit)? = null,
    onDraftChanged: (text: String, images: List<Uri>) -> Unit = { _, _ -> },
    clearDraftVersion: Int = 0,
    drafts: List<dev.rec877.north.Draft> = emptyList(),
    draftsLoading: Boolean = false,
    onOpenDrafts: (() -> Unit)? = null,
    onSubmitWithSavedMediaIds: ((text: String, images: List<Uri>, savedMediaIds: List<String>, onDone: () -> Unit) -> Unit)? = null,
    onReportIssue: (String) -> Unit = {},
    /** 引用画面のように、開いた直後から入力させたいときに true */
    autoFocus: Boolean = false,
) {
    val c = North.colors
    val context = LocalContext.current
    var text by rememberSaveable { mutableStateOf("") }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pickError by remember { mutableStateOf<String?>(null) }
    var restoredMediaIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var draftPickerOpen by remember { mutableStateOf(false) }
    var directPostApproved by rememberSaveable(text) { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    AutoFocus(autoFocus, focusRequester)

    LaunchedEffect(clearDraftVersion) {
        if (clearDraftVersion > 0) { text = ""; images = emptyList() }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(MAX_MEDIA_ITEMS)
    ) { picked ->
        val (ok, bad) = picked.partition { unsupportedMediaReason(context.contentResolver.getType(it)) == null }
        pickError = bad.firstNotNullOfOrNull { unsupportedMediaReason(context.contentResolver.getType(it)) }
        val next = (images + ok).distinct().take(MAX_MEDIA_ITEMS)
        images = next
        onDraftChanged(text, next)
    }

    val weight = postWeight(text)
    val hasDeveloperTag = text.contains("#おうどんに伝えたい")
    val canSend = !posting && (text.isNotBlank() || images.isNotEmpty() || restoredMediaIds.isNotEmpty()) && weight <= MAX_WEIGHT && (!hasDeveloperTag || directPostApproved)

    if (hasDeveloperTag) {
        AppBugReportWarning(
            text = text,
            onReport = onReportIssue,
            onDirectPostApproved = { directPostApproved = it },
        )
    }

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (me != null) Avatar(me, 48.dp, loader)
        else Box(Modifier.size(48.dp).clip(CircleShape).background(c.elev3))

        Column(Modifier.weight(1f)) {
            BasicTextField(
                value = text,
                onValueChange = { text = it; onDraftChanged(it, images) },
                textStyle = TextStyle(color = c.text, fontSize = 20.sp, lineHeight = 26.sp),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 12.dp).focusRequester(focusRequester),
                decorationBox = { inner ->
                    Box {
                        if (text.isEmpty()) {
                            Text("いまどうしてる？", color = c.textMuted, fontSize = 20.sp, lineHeight = 26.sp)
                        }
                        inner()
                    }
                },
            )

            if (images.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    images.forEach { uri ->
                        Box(Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)).background(c.elev2)) {
                            SelectedMediaThumbnail(uri, loader, Modifier.fillMaxSize())
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA000000))
                                    .clickable { val next = images - uri; images = next; onDraftChanged(text, next) },
                                contentAlignment = Alignment.Center,
                            ) { NorthIcon(NIcons.Close, Color.White, 14.dp, modifier = Modifier.size(14.dp)) }
                        }
                    }
                }
            }

            pickError?.let { Text(it, color = c.danger, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp).clickable { pickError = null }) }

            extra?.invoke()

            if (restoredMediaIds.isNotEmpty()) Text("保存済みの添付 ${restoredMediaIds.size} 件", color = c.textMuted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))

            HorizontalDivider(color = c.border)
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val canAdd = images.size < MAX_MEDIA_ITEMS && !posting
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .alpha(if (canAdd) 1f else 0.4f)
                        .clickable(enabled = canAdd) {
                            picker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                    contentAlignment = Alignment.Center,
                ) { NorthIcon(NIcons.Image, c.accent, 22.dp, modifier = Modifier.size(22.dp)) }

                Spacer(Modifier.weight(1f))

                if (text.isNotEmpty()) {
                    Text(
                        "$weight/$MAX_WEIGHT",
                        color = if (weight > MAX_WEIGHT) c.danger else c.textMuted,
                        fontSize = 13.sp,
                    )
                    Spacer(Modifier.width(12.dp))
                }

                // TLの下書きは送信ボタンのすぐ左に置き、片手で続けて操作しやすくする。
                if (onOpenDrafts != null) {
                    Text("下書き", color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(end = 12.dp).clickable { onOpenDrafts(); draftPickerOpen = true })
                }

                // サイトの .composer__submit: 白ピル + 濃い文字
                Box(
                    Modifier
                        .height(36.dp)
                        .clip(CircleShape)
                        .background(c.post.copy(alpha = if (canSend) 1f else 0.5f))
                        .clickable(enabled = canSend) {
                            val done = { text = ""; images = emptyList(); restoredMediaIds = emptyList(); onDraftChanged("", emptyList()) }
                            if (onSubmitWithSavedMediaIds != null) onSubmitWithSavedMediaIds(text, images, restoredMediaIds, done)
                            else onSubmit(text, images, done)
                        }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (posting) "送信中…" else "ポストする",
                        color = c.textOnPost,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
    HorizontalDivider(color = c.border)
    if (draftPickerOpen) AlertDialog(
        onDismissRequest = { draftPickerOpen = false },
        containerColor = c.elev1,
        title = { Text("下書き", color = c.text, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                if (draftsLoading) Text("読み込み中…", color = c.textMuted)
                else if (drafts.isEmpty()) Text("保存された下書きはありません", color = c.textMuted)
                else drafts.take(10).forEach { draft ->
                    val item = draft.items.firstOrNull()
                    Text(item?.text?.ifBlank { "メディアのみの下書き" } ?: "空の下書き", color = c.text, maxLines = 2,
                        modifier = Modifier.fillMaxWidth().clickable { text = item?.text.orEmpty(); images = emptyList(); restoredMediaIds = item?.media?.map { it.id }.orEmpty(); onDraftChanged(text, images); draftPickerOpen = false }.padding(vertical = 12.dp))
                    HorizontalDivider(color = c.border)
                }
            }
        },
        confirmButton = { TextButton(onClick = { draftPickerOpen = false }) { Text("閉じる", color = c.accent) } },
    )
}

/** FABから開く、画面全体を使うモバイル向け投稿画面。 */
@Composable
fun FullScreenComposer(
    me: User?,
    loader: ImageLoader,
    posting: Boolean,
    onClose: () -> Unit,
    drafts: List<dev.rec877.north.Draft>,
    draftsLoading: Boolean,
    onOpenDrafts: () -> Unit,
    /** 本文・画像・保存済み添付・連投の2件目以降・完了時の処理 */
    onSaveDraft: (String, List<Uri>, List<String>, List<String>, () -> Unit) -> Unit,
    onSubmit: (
        text: String, images: List<Uri>, existingMediaIds: List<String>, poll: PollInput?,
        threadTexts: List<String>, replyPolicy: String, onDone: () -> Unit,
    ) -> Unit,
    onReportIssue: (String) -> Unit = {},
    /** アップロード・投稿の失敗。投稿画面は別ウィンドウで背面のバナーが見えないため、ここに出す。 */
    errorMessage: String? = null,
    onDismissError: () -> Unit = {},
) {
    val c = North.colors
    val context = LocalContext.current
    var text by rememberSaveable { mutableStateOf("") }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var pickError by remember { mutableStateOf<String?>(null) }
    var restoredMediaIds by remember { mutableStateOf<List<String>>(emptyList()) }
    var draftPickerOpen by remember { mutableStateOf(false) }
    var confirmSaveOnClose by remember { mutableStateOf(false) }
    var pollOptions by remember { mutableStateOf<List<String>?>(null) }
    var pollEditorOpen by remember { mutableStateOf(false) }
    var pollDays by remember { mutableStateOf("1") }
    var pollHours by remember { mutableStateOf("0") }
    var pollMinutes by remember { mutableStateOf("0") }
    var directPostApproved by rememberSaveable(text) { mutableStateOf(false) }
    // 連投: 2件目以降の本文（最大24件＝合計25件）と、返信できる人
    var threadTexts by remember { mutableStateOf<List<String>>(emptyList()) }
    var replyPolicy by remember { mutableStateOf("EVERYONE") }
    var policyDialogOpen by remember { mutableStateOf(false) }
    val focusRequester = remember { FocusRequester() }
    AutoFocus(enabled = true, focusRequester = focusRequester)
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_MEDIA_ITEMS)) { picked ->
        val (ok, bad) = picked.partition { unsupportedMediaReason(context.contentResolver.getType(it)) == null }
        pickError = bad.firstNotNullOfOrNull { unsupportedMediaReason(context.contentResolver.getType(it)) }
        images = (images + ok).distinct().take(MAX_MEDIA_ITEMS)
    }
    val shownError = pickError ?: errorMessage
    val weight = postWeight(text)
    val normalizedPoll = pollOptions?.map { it.trim() }
    val submittedOptions = normalizedPoll?.filter { it.isNotBlank() }
    val durationMinutes = ((pollDays.toIntOrNull() ?: -1) * 1440) + ((pollHours.toIntOrNull() ?: -1) * 60) + (pollMinutes.toIntOrNull() ?: -1)
    val pollValid = submittedOptions == null || (submittedOptions.size in 2..4 && submittedOptions.all { it.length <= 25 } && durationMinutes in 5..10080)
    val hasDeveloperTag = text.contains("#おうどんに伝えたい")
    val extrasOver = threadTexts.any { postWeight(it) > MAX_WEIGHT }
    val hasExtras = threadTexts.any { it.isNotBlank() }
    val canSend = !posting && (text.isNotBlank() || images.isNotEmpty() || restoredMediaIds.isNotEmpty() || normalizedPoll != null) && weight <= MAX_WEIGHT && !extrasOver && pollValid && (!hasDeveloperTag || directPostApproved)

    Column(
        Modifier.fillMaxSize().background(c.bg).windowInsetsPadding(WindowInsets.safeDrawing).imePadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).clickable {
                if (text.isNotBlank() || images.isNotEmpty() || restoredMediaIds.isNotEmpty() || pollOptions != null || hasExtras) confirmSaveOnClose = true else onClose()
            }, contentAlignment = Alignment.Center) {
                NorthIcon(NIcons.Close, c.text, 26.dp, modifier = Modifier.size(26.dp))
            }
            Spacer(Modifier.weight(1f))
            Text("下書き", color = c.accent, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { onOpenDrafts(); draftPickerOpen = true })
            Spacer(Modifier.width(18.dp))
            Box(
                Modifier.height(44.dp).clip(CircleShape).background(c.accent.copy(alpha = if (canSend) 1f else .45f))
                    .clickable(enabled = canSend) {
                        val poll = submittedOptions?.let { PollInput(it, durationMinutes) }
                        onSubmit(text, images, restoredMediaIds, poll, threadTexts.filter { it.isNotBlank() }, replyPolicy) {
                            text = ""; images = emptyList(); restoredMediaIds = emptyList(); pollOptions = null; threadTexts = emptyList()
                        }
                    }
                    .padding(horizontal = 20.dp), contentAlignment = Alignment.Center,
            ) { Text(if (posting) "送信中…" else "ポストする", color = c.textOnAccent, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
        }
        HorizontalDivider(color = c.border)
        shownError?.let { msg ->
            Text(
                msg, color = c.danger, fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().background(c.elev2)
                    .clickable { pickError = null; onDismissError() }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
        if (hasDeveloperTag) {
            AppBugReportWarning(
                text = text,
                onReport = onReportIssue,
                onDirectPostApproved = { directPostApproved = it },
                modifier = Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
            )
        }
        Row(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 18.dp, vertical = 18.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (me != null) Avatar(me, 48.dp, loader) else Box(Modifier.size(48.dp).clip(CircleShape).background(c.elev3))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    textStyle = TextStyle(color = c.text, fontSize = 22.sp, lineHeight = 30.sp),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 140.dp).focusRequester(focusRequester),
                    decorationBox = { inner -> Box { if (text.isEmpty()) Text("いまどうしてる？", color = c.textMuted, fontSize = 22.sp); inner() } },
                )
                if (images.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        images.forEach { uri ->
                            Box(Modifier.size(112.dp).clip(RoundedCornerShape(14.dp)).background(c.elev2)) {
                                SelectedMediaThumbnail(uri, loader, Modifier.fillMaxSize())
                                Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(28.dp).clip(CircleShape).background(Color(0xBB000000)).clickable { images = images - uri }, contentAlignment = Alignment.Center) {
                                    NorthIcon(NIcons.Close, Color.White, 16.dp, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
                if (restoredMediaIds.isNotEmpty()) Text("保存済みの添付 ${restoredMediaIds.size} 件", color = c.textMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                submittedOptions?.let { options ->
                    Text("投票: ${options.joinToString(" / ")}", color = c.textMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
                }

                // 280字を超えたとき、超えた分を自動で次のポストへ分ける
                if (weight > MAX_WEIGHT) {
                    Text(
                        "280字ごとに分けて連投にする",
                        color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 10.dp).clickable {
                            val parts = splitPostText(text)
                            if (parts.size > 1) {
                                text = parts.first()
                                threadTexts = (parts.drop(1) + threadTexts).take(24)
                            }
                        },
                    )
                }

                // 連投の2件目以降（先頭のポストに、返信として連なる）
                threadTexts.forEachIndexed { index, extraText ->
                    val w = postWeight(extraText)
                    HorizontalDivider(color = c.border, modifier = Modifier.padding(top = 12.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("${index + 2} 件目", color = c.textMuted, fontSize = 13.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("$w/$MAX_WEIGHT", color = if (w > MAX_WEIGHT) c.danger else c.textMuted, fontSize = 13.sp)
                        Spacer(Modifier.width(8.dp))
                        Box(
                            Modifier.size(28.dp).clip(CircleShape).clickable { threadTexts = threadTexts.filterIndexed { i, _ -> i != index } },
                            contentAlignment = Alignment.Center,
                        ) { NorthIcon(NIcons.Close, c.textMuted, 16.dp, modifier = Modifier.size(16.dp)) }
                    }
                    BasicTextField(
                        value = extraText,
                        onValueChange = { v -> threadTexts = threadTexts.mapIndexed { i, old -> if (i == index) v else old } },
                        textStyle = TextStyle(color = c.text, fontSize = 20.sp, lineHeight = 28.sp),
                        cursorBrush = SolidColor(c.accent),
                        modifier = Modifier.fillMaxWidth().heightIn(min = 72.dp).padding(vertical = 6.dp),
                        decorationBox = { inner -> Box { if (extraText.isEmpty()) Text("続きを入力", color = c.textMuted, fontSize = 20.sp); inner() } },
                    )
                }

                // 返信できる人（EVERYONE以外は連投APIで投稿される）
                Text(
                    "🌐 " + replyPolicyLabel(replyPolicy),
                    color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 14.dp, bottom = 12.dp).clickable { policyDialogOpen = true },
                )
            }
        }
        HorizontalDivider(color = c.border)
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            val canAdd = !posting && images.size < MAX_MEDIA_ITEMS
            Box(Modifier.size(44.dp).clip(CircleShape).alpha(if (canAdd) 1f else .4f).clickable(enabled = canAdd) { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }, contentAlignment = Alignment.Center) {
                NorthIcon(NIcons.Image, c.accent, 25.dp, modifier = Modifier.size(25.dp))
            }
            Text(if (pollOptions == null) "投票を追加" else "投票を編集", color = c.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp).clickable { pollEditorOpen = true })
            Spacer(Modifier.weight(1f))
            if (text.isNotEmpty()) { Spacer(Modifier.width(12.dp)); Text("$weight/$MAX_WEIGHT", color = if (weight > MAX_WEIGHT) c.danger else c.textMuted, fontSize = 13.sp) }
            // Web版の「＋」: 続きのポストを追加して、返信ツリーを一度に作成する
            val canAddThread = !posting && threadTexts.size < 24
            Spacer(Modifier.width(12.dp))
            Box(
                Modifier.size(40.dp).clip(CircleShape).border(1.dp, c.borderStrong, CircleShape).alpha(if (canAddThread) 1f else .4f)
                    .clickable(enabled = canAddThread) { threadTexts = threadTexts + "" },
                contentAlignment = Alignment.Center,
            ) { NorthIcon(NIcons.Plus, c.accent, 20.dp, modifier = Modifier.size(20.dp)) }
        }
    }
    if (policyDialogOpen) AlertDialog(
        onDismissRequest = { policyDialogOpen = false },
        containerColor = c.elev1,
        title = { Text("返信できる人", color = c.text, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                listOf("EVERYONE", "FOLLOWING", "MENTIONED").forEach { policy ->
                    Row(
                        Modifier.fillMaxWidth().clickable { replyPolicy = policy; policyDialogOpen = false }.padding(vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(replyPolicyLabel(policy), color = c.text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        if (policy == replyPolicy) Text("✓", color = c.accent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { policyDialogOpen = false }) { Text("閉じる", color = c.accent) } },
    )
    if (draftPickerOpen) AlertDialog(
        onDismissRequest = { draftPickerOpen = false },
        containerColor = c.elev1,
        title = { Text("下書き", color = c.text, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column {
                if (draftsLoading) Text("読み込み中…", color = c.textMuted)
                else if (drafts.isEmpty()) Text("保存された下書きはありません", color = c.textMuted)
                else drafts.take(10).forEach { draft ->
                    val item = draft.items.firstOrNull()
                    Text(item?.text?.ifBlank { "メディアのみの下書き" } ?: "空の下書き", color = c.text, maxLines = 2,
                        modifier = Modifier.fillMaxWidth().clickable {
                            text = item?.text.orEmpty(); images = emptyList(); restoredMediaIds = item?.media?.map { it.id }.orEmpty()
                            threadTexts = draft.items.drop(1).map { it.text }.take(24)
                            item?.replyPolicy?.takeIf { it in listOf("EVERYONE", "FOLLOWING", "MENTIONED") }?.let { replyPolicy = it }
                            draftPickerOpen = false
                        }.padding(vertical = 12.dp))
                    HorizontalDivider(color = c.border)
                }
            }
        },
        confirmButton = { TextButton(onClick = { draftPickerOpen = false }) { Text("閉じる", color = c.accent) } },
    )
    if (pollEditorOpen) AlertDialog(
        onDismissRequest = { pollEditorOpen = false },
        containerColor = c.elev1,
        title = { Text("投票を作成", color = c.text, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("選択肢は2〜4個、各25文字以内です。未入力の選択肢は投稿時に除かれます。", color = c.textMuted, fontSize = 13.sp)
                val editing = pollOptions ?: listOf("", "", "", "")
                editing.forEachIndexed { index, option ->
                    BasicTextField(value = option, onValueChange = { value ->
                        val changed = editing.toMutableList(); changed[index] = value.take(25); pollOptions = changed
                    }, textStyle = TextStyle(color = c.text, fontSize = 16.sp), cursorBrush = SolidColor(c.accent), modifier = Modifier.fillMaxWidth().background(c.elev2, RoundedCornerShape(10.dp)).padding(12.dp), decorationBox = { inner -> Box { if (option.isEmpty()) Text("選択肢 ${index + 1}", color = c.textMuted); inner() } })
                }
                HorizontalDivider(color = c.border)
                Text("アンケート期間", color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PollDurationField("日", pollDays) { pollDays = it.filter(Char::isDigit).take(2) }
                    PollDurationField("時間", pollHours) { pollHours = it.filter(Char::isDigit).take(2) }
                    PollDurationField("分", pollMinutes) { pollMinutes = it.filter(Char::isDigit).take(2) }
                }
                if (!pollValid) Text("選択肢を2〜4個入力し、期間は5分〜7日の範囲にしてください。", color = c.danger, fontSize = 13.sp)
            }
        },
        confirmButton = { TextButton(onClick = { pollOptions = (pollOptions ?: listOf("", "", "", "")); pollEditorOpen = false }) { Text("完了", color = c.accent) } },
        dismissButton = { TextButton(onClick = { pollEditorOpen = false }) { Text("閉じる", color = c.textMuted) } },
    )
    if (confirmSaveOnClose) AlertDialog(
        onDismissRequest = { confirmSaveOnClose = false },
        containerColor = c.elev1,
        title = { Text("下書きを保存しますか？", color = c.text, fontWeight = FontWeight.ExtraBold) },
        text = { Text("投稿せずに閉じると、入力内容と添付を下書きへ保存できます。", color = c.textMuted) },
        confirmButton = { TextButton(onClick = { confirmSaveOnClose = false; onSaveDraft(text, images, restoredMediaIds, threadTexts.filter { it.isNotBlank() }) { onClose() } }) { Text("保存して閉じる", color = c.accent, fontWeight = FontWeight.Bold) } },
        dismissButton = { TextButton(onClick = { confirmSaveOnClose = false; onClose() }) { Text("保存しない", color = c.danger) } },
    )
}

/** 選択した画像または動画の投稿前プレビュー。動画は端末内ファイルから静止画を抽出する。 */
@Composable
internal fun SelectedMediaThumbnail(uri: Uri, loader: ImageLoader, modifier: Modifier = Modifier) {
    val c = North.colors
    val context = LocalContext.current
    val isVideo = remember(uri, context) {
        context.contentResolver.getType(uri)?.startsWith("video/") == true
    }
    Box(modifier.background(c.elev2), contentAlignment = Alignment.Center) {
        if (isVideo) {
            val thumbnail by produceState<ImageBitmap?>(null, uri, context) {
                value = withContext(Dispatchers.IO) { extractVideoThumbnail(context, uri) }
            }
            thumbnail?.let {
                Image(
                    bitmap = it,
                    contentDescription = "選択した動画のプレビュー",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(Color(0x99000000)),
                contentAlignment = Alignment.Center,
            ) {
                Text("▶", color = Color.White, fontSize = 23.sp)
            }
            Text(
                "動画",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.BottomStart).background(Color(0x99000000)).padding(horizontal = 7.dp, vertical = 4.dp),
            )
        } else {
            AsyncImage(
                model = uri,
                imageLoader = loader,
                contentDescription = "選択した画像",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

private fun extractVideoThumbnail(context: android.content.Context, uri: Uri): ImageBitmap? {
    val retriever = MediaMetadataRetriever()
    return try {
        retriever.setDataSource(context, uri)
        val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        val frameTimeUs = minOf(durationMs / 2, 1_000L) * 1_000L
        val frame = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 512
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 512
            val scale = minOf(1f, 512f / maxOf(width, height).coerceAtLeast(1))
            retriever.getScaledFrameAtTime(
                frameTimeUs,
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                (width * scale).toInt().coerceAtLeast(1),
                (height * scale).toInt().coerceAtLeast(1),
            )
        } else {
            retriever.getFrameAtTime(frameTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        }
        frame?.asImageBitmap()
    } catch (_: Exception) {
        null
    } finally {
        runCatching { retriever.release() }
    }
}

/** 開発者向けタグを含む投稿を、誤って一般のSNS不具合窓口へ流さないための確認UI。 */
@Composable
private fun AppBugReportWarning(
    text: String,
    onReport: (String) -> Unit,
    onDirectPostApproved: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val c = North.colors
    var holding by rememberSaveable(text) { mutableStateOf(false) }
    var approved by rememberSaveable(text) { mutableStateOf(false) }
    var secondsRemaining by rememberSaveable(text) { mutableStateOf(30) }
    var holdProgress by rememberSaveable(text) { mutableStateOf(0f) }
    var reportFormOpen by rememberSaveable(text) { mutableStateOf(false) }
    var issueDescription by rememberSaveable(text) { mutableStateOf("") }

    LaunchedEffect(holding, approved) {
        if (!holding || approved) return@LaunchedEffect
        secondsRemaining = 30
        holdProgress = 0f
        repeat(30) { index ->
            delay(1_000)
            if (!holding) return@LaunchedEffect
            secondsRemaining = 29 - index
            holdProgress = (index + 1) / 30f
        }
        if (holding) approved = true
    }
    // 指を離すと長押しの進捗は残さず、次回は最初から数える。
    LaunchedEffect(holding) {
        if (!holding && !approved) {
            secondsRemaining = 30
            holdProgress = 0f
        }
    }
    LaunchedEffect(approved) { onDirectPostApproved(approved) }

    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(c.elev2).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("アプリ版への不具合報告を検出しました", color = c.text, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        Text("開発者へ直接送れば、この内容はSNSに公開されません。通常投稿する場合は誤送信防止のため30秒間の長押しが必要です。", color = c.textMuted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.clip(CircleShape).background(c.accent).clickable { reportFormOpen = true }.padding(horizontal = 13.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center,
            ) { Text("開発者に知らせる", color = c.textOnAccent, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
            if (approved) {
                Text("通常投稿を許可しました", color = c.accent, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            } else {
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(c.elev3)
                        // 描画だけで進捗を重ねる。子要素のfillMaxHeightで親Rowを全画面まで
                        // 押し広げないようにし、ボタン自身の通常サイズを維持する。
                        .drawBehind {
                            drawRect(
                                color = c.accent,
                                size = Size(size.width * holdProgress, size.height),
                            )
                        }
                        .pointerInput(text) {
                            detectTapGestures(onPress = {
                                holding = true
                                tryAwaitRelease()
                                holding = false
                            })
                        }
                        .padding(horizontal = 13.dp, vertical = 9.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text("そのまま投稿（${secondsRemaining}秒長押し）", color = c.text, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
    if (reportFormOpen) AlertDialog(
        onDismissRequest = { reportFormOpen = false },
        containerColor = c.elev1,
        title = { Text("アプリの開発者に知らせる", color = c.text, fontWeight = FontWeight.ExtraBold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("どのような不具合か、再現する手順や期待した動きを入力してください。元の投稿内容も添えて、SNSには公開せず開発者へ送ります。", color = c.textMuted, fontSize = 13.sp)
                BasicTextField(
                    value = issueDescription,
                    onValueChange = { issueDescription = it.take(1_500) },
                    textStyle = TextStyle(color = c.text, fontSize = 15.sp),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth().heightIn(min = 130.dp).background(c.elev2, RoundedCornerShape(10.dp)).padding(12.dp),
                    decorationBox = { inner -> Box { if (issueDescription.isEmpty()) Text("例: 検索後に一覧が途中までスクロールされる\n再現手順: 検索タブで…", color = c.textMuted, fontSize = 14.sp); inner() } },
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = issueDescription.isNotBlank(),
                onClick = {
                    onReport("$text\n\n【不具合の詳細】\n${issueDescription.trim()}")
                    reportFormOpen = false
                    issueDescription = ""
                },
            ) { Text("送信", color = c.accent, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = { reportFormOpen = false }) { Text("戻る", color = c.textMuted) } },
    )
}

@Composable
private fun RowScope.PollDurationField(label: String, value: String, onValueChange: (String) -> Unit) {
    val c = North.colors
    Column(Modifier.weight(1f)) {
        Text(label, color = c.textMuted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp))
        BasicTextField(value = value, onValueChange = onValueChange, textStyle = TextStyle(color = c.text, fontSize = 16.sp), cursorBrush = SolidColor(c.accent), modifier = Modifier.fillMaxWidth().background(c.elev2, RoundedCornerShape(8.dp)).padding(10.dp))
    }
}