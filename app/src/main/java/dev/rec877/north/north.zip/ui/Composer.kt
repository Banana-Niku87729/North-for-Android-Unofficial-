package dev.rec877.north.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import coil3.compose.AsyncImage
import dev.rec877.north.User
import dev.rec877.north.ui.theme.North

private const val MAX_IMAGES = 4
private const val MAX_WEIGHT = 280

/**
 * サイトの .composer を再現。下段に「画像を追加」(アクセント色)と「ポストする」(白ピル)。
 * 画像はAndroidのフォトピッカー（権限不要）で最大4枚。送信時にアップロードしてから投稿する。
 */
@Composable
fun Composer(
    me: User?,
    loader: ImageLoader,
    posting: Boolean,
    onSubmit: (text: String, images: List<Uri>, onDone: () -> Unit) -> Unit,
    /** 画像サムネイルの下に差し込む内容（引用するポストのカードなど） */
    extra: (@Composable () -> Unit)? = null,
) {
    val c = North.colors
    var text by rememberSaveable { mutableStateOf("") }
    var images by remember { mutableStateOf<List<Uri>>(emptyList()) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia(MAX_IMAGES)
    ) { picked -> images = (images + picked).distinct().take(MAX_IMAGES) }

    val weight = postWeight(text)
    val canSend = !posting && (text.isNotBlank() || images.isNotEmpty()) && weight <= MAX_WEIGHT

    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (me != null) Avatar(me, 48.dp, loader)
        else Box(Modifier.size(48.dp).clip(CircleShape).background(c.elev3))

        Column(Modifier.weight(1f)) {
            BasicTextField(
                value = text,
                onValueChange = { text = it },
                textStyle = TextStyle(color = c.text, fontSize = 20.sp, lineHeight = 26.sp),
                cursorBrush = SolidColor(c.accent),
                modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 12.dp),
                decorationBox = { inner ->
                    Box {
                        if (text.isEmpty()) {
                            Text("いまどうしてる？", color = c.textMuted, fontSize = 20.sp, lineHeight = 26.sp)
                        }
                        inner()
                    }
                },
            )

            if (images.isNotEmpty()) {
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    images.forEach { uri ->
                        Box(Modifier.size(96.dp).clip(RoundedCornerShape(12.dp)).background(c.elev2)) {
                            AsyncImage(
                                model = uri,
                                imageLoader = loader,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize(),
                            )
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(4.dp)
                                    .size(24.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xAA000000))
                                    .clickable { images = images - uri },
                                contentAlignment = Alignment.Center,
                            ) { NorthIcon(NIcons.Close, Color.White, 14.dp, modifier = Modifier.size(14.dp)) }
                        }
                    }
                }
            }

            extra?.invoke()

            HorizontalDivider(color = c.border)
            Row(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                val canAdd = images.size < MAX_IMAGES && !posting
                Box(
                    Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .alpha(if (canAdd) 1f else 0.4f)
                        .clickable(enabled = canAdd) {
                            picker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                    contentAlignment = Alignment.Center,
                ) { NorthIcon(NIcons.Image, c.accent, 22.dp, modifier = Modifier.size(22.dp)) }

                Spacer(Modifier.weight(1f))

                if (text.isNotEmpty()) {
                    Text(
                        "$weight/$MAX_WEIGHT",
                        color = if (weight > MAX_WEIGHT) c.danger else c.textMuted,
                        fontSize = 13.sp,
                    )
                    Spacer(Modifier.width(12.dp))
                }

                // サイトの .composer__submit: 白ピル + 濃い文字
                Box(
                    Modifier
                        .height(36.dp)
                        .clip(CircleShape)
                        .background(c.post.copy(alpha = if (canSend) 1f else 0.5f))
                        .clickable(enabled = canSend) {
                            onSubmit(text, images) { text = ""; images = emptyList() }
                        }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (posting) "送信中…" else "ポストする",
                        color = c.textOnPost,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
    HorizontalDivider(color = c.border)
}