package dev.rec877.north

import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request

@Serializable data class Tokens(val accessToken: String, val refreshToken: String, val expiresAtMs: Long)
@Serializable private data class Pending(val verifier: String, val state: String)

class NotLoggedInException : Exception("ログインが必要です")
class AuthException(message: String) : Exception(message)

class AuthRepository(private val secrets: SecretStore, private val http: OkHttpClient) {
    private val json = Json { ignoreUnknownKeys = true }

    /**
     * 更新トークンはローテーション式で、使用済みの再利用を検出すると許可全体が止まる。
     * 読み出し→更新→保存を必ずこのMutexの中で行い、同時更新を防ぐ。
     */
    private val mutex = Mutex()

    fun isLoggedIn(): Boolean = secrets.get(K_TOKENS) != null

    // ---------- ログイン開始 ----------
    fun buildAuthorizeUri(): Uri {
        val verifier = Pkce.randomString()
        val state = Pkce.randomString(16)
        // ブラウザに行っている間にプロセスが死んでも続けられるよう、永続化しておく
        secrets.put(K_PENDING, json.encodeToString(Pending(verifier, state)))
        return Uri.parse("${Config.API_BASE}/oauth/authorize").buildUpon()
            .appendQueryParameter("client_id", Config.CLIENT_ID)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("redirect_uri", Config.REDIRECT_URI)
            .appendQueryParameter("scope", Config.SCOPES)
            .appendQueryParameter("state", state)
            .appendQueryParameter("code_challenge", Pkce.challenge(verifier))
            .appendQueryParameter("code_challenge_method", "S256")
            .build()
    }

    // ---------- リダイレクト受け取り（認可codeは60秒・1回限り。すぐ交換する）----------
    suspend fun handleRedirect(uri: Uri) {
        val pending = secrets.get(K_PENDING)?.let { json.decodeFromString<Pending>(it) }
            ?: throw AuthException("ログイン要求が見つかりません。もう一度お試しください")
        secrets.remove(K_PENDING)

        uri.getQueryParameter("error")?.let { throw AuthException("認可が拒否されました: $it") }
        if (uri.getQueryParameter("state") != pending.state) throw AuthException("stateが一致しません")
        val code = uri.getQueryParameter("code") ?: throw AuthException("codeがありません")

        val (status, text) = postForm(
            "/oauth/token",
            mapOf(
                "grant_type" to "authorization_code",
                "client_id" to Config.CLIENT_ID,
                "code" to code,
                "code_verifier" to pending.verifier,
                "redirect_uri" to Config.REDIRECT_URI,
            )
        )
        val tokens = parseTokens(status, text)
        mutex.withLock { saveTokens(tokens) }
    }

    // ---------- アクセストークン取得（期限が近ければ更新）----------
    suspend fun accessToken(): String = mutex.withLock {
        val t = loadTokens() ?: throw NotLoggedInException()
        if (System.currentTimeMillis() < t.expiresAtMs - 60_000) t.accessToken else refreshLocked(t).accessToken
    }

    /** 401が返った時用。他の呼び出しが既に更新済みなら、更新せずその値を返す */
    suspend fun refreshAfter(failedAccessToken: String): String = mutex.withLock {
        val t = loadTokens() ?: throw NotLoggedInException()
        if (t.accessToken != failedAccessToken) t.accessToken else refreshLocked(t).accessToken
    }

    suspend fun logout() {
        val t = loadTokens()
        if (t != null) {
            // 「このアプリの許可全体を取り消す」。tokenにどちらを渡すかは仕様に明記がないので要確認
            runCatching {
                postForm("/oauth/revoke", mapOf("client_id" to Config.CLIENT_ID, "token" to t.refreshToken))
            }
        }
        secrets.remove(K_TOKENS)
    }

    // ---------- 内部 ----------
    private suspend fun refreshLocked(t: Tokens): Tokens {
        val (status, text) = postForm(
            "/oauth/token",
            mapOf(
                "grant_type" to "refresh_token",
                "client_id" to Config.CLIENT_ID,
                "refresh_token" to t.refreshToken,
            )
        )
        if (status == 400 && text.contains("invalid_grant")) {
            secrets.remove(K_TOKENS) // 期限切れ・取り消し済み → 再ログインが必要
            throw NotLoggedInException()
        }
        // ネットワーク例外はそのまま投げる（トークンは消さない）
        val fresh = parseTokens(status, text)
        saveTokens(fresh)
        return fresh
    }

    private fun parseTokens(status: Int, text: String): Tokens {
        if (status != 200) {
            val err = runCatching { json.decodeFromString<OAuthError>(text).error }.getOrNull()
            throw AuthException(err ?: "トークン取得に失敗しました (HTTP $status)")
        }
        val r = json.decodeFromString<TokenResponse>(text)
        return Tokens(r.accessToken, r.refreshToken, System.currentTimeMillis() + r.expiresIn * 1000L)
    }

    private fun loadTokens(): Tokens? = secrets.get(K_TOKENS)?.let { json.decodeFromString<Tokens>(it) }
    private fun saveTokens(t: Tokens) = secrets.put(K_TOKENS, json.encodeToString(t))

    private suspend fun postForm(path: String, form: Map<String, String>): Pair<Int, String> =
        withContext(Dispatchers.IO) {
            val body = FormBody.Builder().apply { form.forEach { (k, v) -> add(k, v) } }.build()
            val req = Request.Builder().url(Config.API_BASE + path).post(body).build()
            http.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
        }

    private companion object {
        const val K_TOKENS = "tokens"
        const val K_PENDING = "pending"
    }
}
