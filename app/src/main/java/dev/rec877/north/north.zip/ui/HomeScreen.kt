@file:OptIn(ExperimentalMaterial3Api::class)

package dev.rec877.north.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import coil3.ImageLoader
import dev.rec877.north.MainViewModel
import dev.rec877.north.Media
import dev.rec877.north.Post
import dev.rec877.north.ui.theme.North

/**
 * ログイン後の全体:
 * エラー表示バー + 画面(ホーム/検索/通知) + その上に重ねる画面(ポスト詳細/プロフィール)
 * + 下部ナビ + 返信ダイアログ + メディアビューア
 */
@Composable
fun AppShell(vm: MainViewModel, loader: ImageLoader) {
    val c = North.colors
    val ui = vm.ui

    var tab by rememberSaveable { mutableIntStateOf(0) }
    // リポストボタンで開く選択肢（リポスト/引用）と、引用の作成画面の対象
    var repostTarget by remember { mutableStateOf<Post?>(null) }
    var quoteTarget by remember { mutableStateOf<Post?>(null) }
    var viewer by remember { mutableStateOf<Pair<List<Media>, Int>?>(null) }

    // キーボードが出ている間は下部ナビを隠して、入力欄の上の余白を確保する
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    val stack = vm.backStack
    val top = stack.lastOrNull()

    // 戻るボタン: 重ねている画面があれば1つ閉じる
    BackHandler(enabled = top != null) { vm.back() }

    // スクロール位置はここで持つ（タブを切り替えても戻ってきたとき保たれる）。
    // 検索結果は「語句 + タブ」が変わるたびに新しい状態にして、必ず先頭から表示する。
    val homeListState = rememberLazyListState()
    val notifListState = rememberLazyListState()
    val searchListState = rememberSaveable(
        vm.search.query, vm.search.tab, saver = LazyListState.Saver
    ) { LazyListState() }

    // 画面が見えている間だけ通知のSSEをつなぐ（裏に回ったら切る）
    val lifecycleOwner = LocalLifecycleOwner.current
    LaunchedEffect(vm, lifecycleOwner) {
        lifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) { vm.runNotificationStream() }
    }

    // 通知を開いている間は「見ている」。別のタブへ移る・ポスト詳細などを開くと「見終わった」ので、自動で既読にする
    val notifShowing = tab == 2 && top == null
    LaunchedEffect(notifShowing) { if (notifShowing) vm.onNotifTabShown() else vm.onNotifTabHidden() }

    // スマホへの通知の許可（Android 13以上。最初の1回だけ聞く）
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && vm.shouldAskNotifPermission()) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val actions = remember(vm) {
        PostActions(
            // 返信ボタン: ポスト詳細を開いて、下の入力欄にカーソルを置く（ポップアップは出さない）
            onReply = { vm.openPost(it.id, focusReply = true) },
            onLike = { vm.toggleLike(it) },
            onRepost = { repostTarget = it },
            onOpenMedia = { list, i -> viewer = list to i },
            onOpenPost = { vm.openPost(it.id) },
            onOpenUser = { vm.openUser(it.handle) },
        )
    }

    Column(Modifier.fillMaxSize().background(c.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
        ui.message?.let { msg ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(c.elev2)
                    .padding(start = 16.dp, end = 8.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(
                    msg,
                    color = c.danger,
                    fontSize = 14.sp,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { vm.dismissMessage() }
                        .padding(vertical = 6.dp),
                )
                if (ui.reloginHint) {
                    // 権限不足(code 87)のとき: ログアウト→再ログインで新しい権限を許可し直す
                    TextButton(onClick = { vm.logout() }) { Text("再ログイン", color = c.accent) }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (tab) {
                0 -> HomeContent(vm, loader, actions, homeListState)
                1 -> SearchScreen(vm, loader, actions, searchListState)
                else -> NotificationsScreen(vm, loader, notifListState)
            }

            if (top != null) {
                // 下の画面にタップが抜けないよう、pointerInput で受け止める
                Box(Modifier.fillMaxSize().background(c.bg).pointerInput(Unit) {}) {
                    key(top) {
                        when {
                            top.startsWith("post:") -> ThreadScreen(vm, loader, top.removePrefix("post:"), actions)
                            top.startsWith("user:") -> ProfileScreen(vm, loader, top.removePrefix("user:"), actions)
                        }
                    }
                }
            }
        }

        if (!imeOpen) {
            BottomBar(
                selected = tab,
                unread = vm.notif.unread,
                onSelect = { i ->
                    vm.popToRoot() // タブを押したら、重ねていた画面は閉じる
                    tab = i
                },
            )
        }
    }

    repostTarget?.let { target ->
        RepostSheet(
            post = target,
            onRepost = { vm.toggleRepost(target); repostTarget = null },
            onQuote = { quoteTarget = target; repostTarget = null },
            onDismiss = { repostTarget = null },
        )
    }

    quoteTarget?.let { target ->
        QuoteDialog(vm, target, loader) { quoteTarget = null }
    }

    viewer?.let { (list, index) ->
        MediaViewer(list, index, loader, vm.imageClient) { viewer = null }
    }
}

@Composable
private fun BottomBar(selected: Int, unread: Int, onSelect: (Int) -> Unit) {
    val c = North.colors
    Column {
        HorizontalDivider(color = c.border)
        Row(Modifier.fillMaxWidth().height(52.dp).background(c.bg)) {
            listOf(
                Triple(NIcons.Home, "ホーム", 0),
                Triple(NIcons.Search, "検索", 1),
                Triple(NIcons.Bell, "通知", 2),
            ).forEach { (icon, label, i) ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .semantics { contentDescription = label }
                        .clickable(role = Role.Tab) { onSelect(i) },
                    contentAlignment = Alignment.Center,
                ) {
                    Box {
                        NorthIcon(
                            icon,
                            if (i == selected) c.accent else c.textMuted,
                            26.dp,
                            filled = i == 0 && selected == 0,
                            modifier = Modifier.size(26.dp),
                        )
                        // サイトの .nav__badge: アクセント色の丸（99超は 99+）
                        if (i == 2 && unread > 0) {
                            Box(
                                Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 10.dp, y = (-4).dp)
                                    .defaultMinSize(minWidth = 18.dp, minHeight = 18.dp)
                                    .clip(CircleShape)
                                    .background(c.accent)
                                    .padding(horizontal = 5.dp),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text(
                                    if (unread > 99) "99+" else unread.toString(),
                                    color = c.textOnAccent,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeContent(
    vm: MainViewModel,
    loader: ImageLoader,
    actions: PostActions,
    listState: LazyListState,
) {
    val c = North.colors
    val ui = vm.ui
    var menuOpen by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        // ---- ヘッダー（サイトの .head: 左にアバター、タイトル、右に切り替えボタン）----
        Row(
            Modifier.fillMaxWidth().height(53.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                val me = ui.me
                if (me != null) {
                    Avatar(me, 32.dp, loader, Modifier.clickable { menuOpen = true })
                } else {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(c.elev3))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    me?.let {
                        DropdownMenuItem(
                            text = { Text("プロフィール  @${it.handle}") },
                            onClick = { menuOpen = false; vm.openUser(it.handle) },
                        )
                    }
                    DropdownMenuItem(
                        text = {
                            Text(if (vm.bgNotif) "バックグラウンド通知: オン" else "バックグラウンド通知: オフ")
                        },
                        onClick = { menuOpen = false; vm.updateBgNotif(!vm.bgNotif) },
                    )
                    DropdownMenuItem(
                        text = { Text("ログアウト") },
                        onClick = { menuOpen = false; vm.logout() },
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Text(
                if (ui.ranked) "おすすめ" else "最新ポスト",
                color = c.text,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f),
            )
            // 「最新ポスト」⇄「おすすめ」の切り替え（サイトの✦ボタン）
            Box(
                Modifier.size(40.dp).clip(CircleShape).clickable { vm.toggleRanked() },
                contentAlignment = Alignment.Center,
            ) {
                NorthIcon(
                    NIcons.Sparkle,
                    if (ui.ranked) c.accent else c.textMuted,
                    20.dp,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
        HorizontalDivider(color = c.border)

        PullToRefreshBox(
            isRefreshing = ui.refreshing,
            onRefresh = { vm.refresh() },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) {
            LazyColumn(Modifier.fillMaxSize(), state = listState) {
                item(key = "composer") {
                    Composer(
                        me = ui.me,
                        loader = loader,
                        posting = ui.posting,
                        onSubmit = { text, images, onDone -> vm.post(text, images, onDone = onDone) },
                    )
                }

                items(ui.posts, key = { it.id }) { post -> PostCard(post, loader, actions) }

                if (ui.nextCursor != null) {
                    item(key = "more") {
                        // 末尾が見えたら次ページを読む
                        LaunchedEffect(ui.nextCursor) { vm.loadMore() }
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                color = c.accent,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                } else if (!ui.refreshing && ui.posts.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            "ポストがありません",
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun LoginScreen(vm: MainViewModel) {
    val c = North.colors
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(c.bg).windowInsetsPadding(WindowInsets.safeDrawing).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("north", color = c.accent, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("northのアカウントでログインします", color = c.textMuted, fontSize = 15.sp)
        Spacer(Modifier.height(32.dp))
        Box(
            Modifier
                .height(48.dp)
                .clip(CircleShape)
                .background(c.post)
                .clickable { CustomTabsIntent.Builder().build().launchUrl(ctx, vm.authorizeUri()) }
                .padding(horizontal = 32.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("northでログイン", color = c.textOnPost, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        vm.ui.message?.let {
            Spacer(Modifier.height(24.dp))
            Text(it, color = c.danger, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}