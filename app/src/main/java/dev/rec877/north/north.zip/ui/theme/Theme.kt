package dev.rec877.north.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

/** north.rip の CSS変数（--north-*）に対応するパレット */
@Immutable
class NorthColors(
    val bg: Color,
    val elev1: Color,
    val elev2: Color,
    val elev3: Color,
    val border: Color,
    val borderStrong: Color,
    val text: Color,
    val textMuted: Color,
    val textFaint: Color,
    val accent: Color,
    val textOnAccent: Color,
    val like: Color,
    val repost: Color,
    /** 「ポストする」ボタンの背景/文字色（--north-post / --north-text-on-post） */
    val post: Color,
    val textOnPost: Color,
    val danger: Color,
)

/** サイトの設定: テーマ=midnight / アクセント=yellow */
val MidnightYellow = NorthColors(
    bg = Color(0xFF040512),
    elev1 = Color(0xFF0A0C1E),
    elev2 = Color(0xFF10132B),
    elev3 = Color(0xFF181C3A),
    border = Color(0xFF181C3A),
    borderStrong = Color(0xFF333863),
    text = Color(0xFFE7E9F2),
    textMuted = Color(0xFF8489B8),
    textFaint = Color(0xFF666B95),
    accent = Color(0xFFFFD400),
    textOnAccent = Color(0xFF0F1419),
    like = Color(0xFFF91880),
    repost = Color(0xFF00BA7C),
    post = Color(0xFFFFFFFF),
    textOnPost = Color(0xFF040512),
    danger = Color(0xFFF4212E),
)

val LocalNorthColors = staticCompositionLocalOf { MidnightYellow }

object North {
    val colors: NorthColors
        @Composable @ReadOnlyComposable get() = LocalNorthColors.current
}

@Composable
fun NorthTheme(colors: NorthColors = MidnightYellow, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = colors.accent,
        onPrimary = colors.textOnAccent,
        background = colors.bg,
        onBackground = colors.text,
        surface = colors.bg,
        onSurface = colors.text,
        surfaceVariant = colors.elev2,
        onSurfaceVariant = colors.textMuted,
        surfaceContainer = colors.elev2,
        surfaceContainerHigh = colors.elev2,
        outline = colors.border,
        error = colors.danger,
    )
    CompositionLocalProvider(LocalNorthColors provides colors) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
