package dev.rec877.north.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import dev.rec877.north.MainViewModel
import dev.rec877.north.ui.theme.North

/** モバイルWeb版の drawer 構成に寄せた、全画面スクリーン＋左パネルのアカウントメニュー。 */
@Composable
fun AccountDrawer(vm: MainViewModel, loader: ImageLoader, onDismiss: () -> Unit) {
    val c = North.colors
    val me = vm.ui.me
    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Color(0x99000000)).clickable(onClick = onDismiss))
        // enableEdgeToEdge中でも、通知領域・ナビゲーション領域の下へ文字を置かない。
        Column(Modifier.fillMaxHeight().width(300.dp).background(c.bg).windowInsetsPadding(WindowInsets.safeDrawing)) {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("アカウント情報", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onDismiss), contentAlignment = Alignment.Center) { NorthIcon(NIcons.Close, c.text, 20.dp, modifier = Modifier.size(20.dp)) }
            }
            me?.let { user ->
                Column(Modifier.fillMaxWidth().clickable { onDismiss(); vm.openUser(user.handle) }.padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Avatar(user, 48.dp, loader, Modifier.size(48.dp)); Text(user.name, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp)); Text("@${user.handle}", color = c.textMuted, fontSize = 14.sp)
                }
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    Text("${user.followingCount} フォロー中", color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clickable { onDismiss(); vm.open(dev.rec877.north.Dest.follows(user.handle, "following")) })
                    Text("${user.followerCount} フォロワー", color = c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clickable { onDismiss(); vm.open(dev.rec877.north.Dest.follows(user.handle, "followers")) })
                }
            }
            HorizontalDivider(color = c.border)
            DrawerRow(NIcons.Person, "プロフィール") { me?.let { onDismiss(); vm.openUser(it.handle) } }
            DrawerRow(NIcons.Sparkle, "設定") { onDismiss(); vm.openSettings() }
            HorizontalDivider(color = c.border, modifier = Modifier.padding(top = 8.dp))
            DrawerRow(NIcons.Bell, if (vm.bgNotif) "バックグラウンド通知　オン" else "バックグラウンド通知　オフ") { vm.updateBgNotif(!vm.bgNotif) }
            DrawerRow(NIcons.Close, "ログアウト", danger = true) { onDismiss(); vm.logout() }
        }
    }
}

@Composable private fun DrawerRow(icon: NIcon, label: String, danger: Boolean = false, onClick: () -> Unit) {
    val c = North.colors
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
        NorthIcon(icon, if (danger) c.danger else c.text, 22.dp, modifier = Modifier.size(22.dp)); Text(label, color = if (danger) c.danger else c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}
