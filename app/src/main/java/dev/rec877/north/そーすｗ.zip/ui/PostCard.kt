package dev.rec877.north.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import coil3.compose.AsyncImage
import dev.rec877.north.Config
import dev.rec877.north.Media
import dev.rec877.north.Post
import dev.rec877.north.User
import dev.rec877.north.R
import dev.rec877.north.ui.theme.North

/** ホーム・検索・詳細・プロフィールで共有する、ポストへの操作 */
class PostActions(
    val onReply: (Post) -> Unit,
    val onLike: (Post) -> Unit,
    val onRepost: (Post) -> Unit,
    val onOpenMedia: (List<Media>, Int) -> Unit,
    val onOpenPost: (Post) -> Unit,
    val onOpenUser: (User) -> Unit,
)

@Composable
fun Avatar(user: User, size: Dp, loader: ImageLoader, modifier: Modifier = Modifier) {
    val c = North.colors
    val url = Config.absUrl(user.avatarUrl)
    Box(
        modifier.size(size).clip(CircleShape).background(c.elev3),
        contentAlignment = Alignment.Center,
    ) {
        if (url != null) {
            AsyncImage(
                model = url,
                imageLoader = loader,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        } else {
            Text(
                user.name.take(1),
                color = c.textMuted,
                fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.4f).sp,
            )
        }
    }
}

/**
 * サイトの .tweet を再現: 左に48dpアバター、右に本文。
 * リポストは「○○さんがリポストしました」を上に出し、中身は元ポストを表示する。
 * 返信/リポスト/いいねは元ポスト(shown)に対して行う。
 * 行をタップ → ポスト詳細、アイコン/名前をタップ → プロフィール。
 */
@Composable
fun PostCard(post: Post, loader: ImageLoader, actions: PostActions) {
    val c = North.colors
    val shown = post.retweetOf ?: post

    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .clickable { actions.onOpenPost(shown) }
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Avatar(shown.author, 48.dp, loader, Modifier.clickable { actions.onOpenUser(shown.author) })

            Column(Modifier.weight(1f)) {
                if (post.retweetOf != null) {
                    Row(
                        Modifier
                            .padding(bottom = 2.dp)
                            .clickable { actions.onOpenUser(post.author) },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        NorthIcon(NIcons.Repost, c.textMuted, 14.dp, modifier = Modifier.size(14.dp))
                        Text(
                            "${post.author.name}さんがリポストしました",
                            color = c.textMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                }

                // 名前 @handle · 時間
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        shown.author.name,
                        color = c.text,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier
                            .weight(1f, fill = false)
                            .clickable { actions.onOpenUser(shown.author) },
                    )
                    UserBadges(shown.author)
                    Text(
                        "@${shown.author.handle}",
                        color = c.textMuted,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(start = 4.dp).weight(1f, fill = false),
                    )
                    Text(
                        " · ${relativeTime(shown.createdAt)}",
                        color = c.textMuted,
                        fontSize = 15.sp,
                        maxLines = 1,
                    )
                }

                if (shown.unavailable) {
                    Text("このポストは表示できません", color = c.textMuted, fontSize = 15.sp)
                } else {
                    if (!shown.inReplyToHandle.isNullOrBlank()) {
                        Text("@${shown.inReplyToHandle} に返信", color = c.textMuted, fontSize = 13.sp)
                    }
                    if (shown.text.isNotEmpty()) {
                        Text(shown.text, color = c.text, fontSize = 16.sp, lineHeight = 22.sp)
                    }
                    if (shown.media.isNotEmpty()) {
                        MediaGrid(
                            media = shown.media,
                            loader = loader,
                            onOpen = { i -> actions.onOpenMedia(shown.media, i) },
                        )
                    }
                    shown.quoted?.let { QuotedPost(it, loader, actions) }
                }

                // アクション: 返信 / リポスト / いいね（カウントは0なら出さない）
                Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    Box(Modifier.weight(1f)) {
                        ActionButton(NIcons.Reply, shown.replyCount, c.textMuted, active = false) {
                            actions.onReply(shown)
                        }
                    }
                    Box(Modifier.weight(1f)) {
                        ActionButton(
                            NIcons.Repost, shown.retweetCount,
                            if (shown.retweeted) c.repost else c.textMuted,
                            active = false,
                        ) { actions.onRepost(shown) }
                    }
                    Box(Modifier.weight(1f)) {
                        ActionButton(
                            NIcons.Like, shown.likeCount,
                            if (shown.liked) c.like else c.textMuted,
                            active = shown.liked,
                        ) { actions.onLike(shown) }
                    }
                    Spacer(Modifier.weight(1f))
                }
            }
        }
        HorizontalDivider(color = c.border)
    }
}

/** 認証済み・非公開アカウントであることを、プロフィール以外の投稿一覧でも明示する。 */
@Composable
fun UserBadges(user: User, compact: Boolean = true) {
    val c = North.colors
    if (user.verified) {
        androidx.compose.foundation.Image(painterResource(R.drawable.ic_verified), null, Modifier.padding(start = 4.dp).size(if (compact) 15.dp else 18.dp), colorFilter = ColorFilter.tint(c.accent))
    }
    if (user.isProtected) androidx.compose.foundation.Image(painterResource(R.drawable.ic_locked), null, Modifier.padding(start = 3.dp).size(if (compact) 14.dp else 17.dp), colorFilter = ColorFilter.tint(c.text))
}

/** 引用しているポスト: 角丸の枠の中に、投稿者・本文・画像を小さく出す。タップでそのポストへ */
@Composable
fun QuotedPost(q: Post, loader: ImageLoader, actions: PostActions) {
    val c = North.colors
    val shape = RoundedCornerShape(16.dp)
    Column(
        Modifier
            .padding(top = 12.dp)
            .fillMaxWidth()
            .clip(shape)
            .border(1.dp, c.border, shape)
            .clickable { actions.onOpenPost(q) }
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Avatar(q.author, 20.dp, loader)
            Text(
                q.author.name,
                color = c.text,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f, fill = false),
            )
            Text(
                "@${q.author.handle} · ${relativeTime(q.createdAt)}",
                color = c.textMuted,
                fontSize = 14.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (q.unavailable) {
            Text("このポストは表示できません", color = c.textMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
        } else {
            if (q.text.isNotEmpty()) {
                Text(
                    q.text,
                    color = c.text,
                    fontSize = 15.sp,
                    lineHeight = 20.sp,
                    maxLines = 6,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            if (q.media.isNotEmpty()) {
                MediaGrid(media = q.media, loader = loader, onOpen = { i -> actions.onOpenMedia(q.media, i) })
            }
        }
    }
}

@Composable
fun ActionButton(
    icon: NIcon,
    count: Int,
    tint: Color,
    active: Boolean,
    onClick: () -> Unit,
) {
    Row(
        Modifier
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        NorthIcon(icon, tint, 19.dp, filled = active, modifier = Modifier.size(19.dp))
        if (count > 0) Text(count.toString(), color = tint, fontSize = 13.sp)
    }
}
