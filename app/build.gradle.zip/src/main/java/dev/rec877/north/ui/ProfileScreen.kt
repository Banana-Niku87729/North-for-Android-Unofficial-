package dev.rec877.north.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import coil3.compose.AsyncImage
import dev.rec877.north.Config
import dev.rec877.north.Dest
import dev.rec877.north.MainViewModel
import dev.rec877.north.Post
import dev.rec877.north.PostPage
import dev.rec877.north.ScreenController
import dev.rec877.north.User
import dev.rec877.north.patched
import dev.rec877.north.ui.theme.North

/** ページ送りのあるポスト一覧（プロフィールの「ポスト」「いいね」タブ用） */
class PagedPosts(private val fetch: suspend (String?) -> PostPage) {
    var items by mutableStateOf<List<Post>>(emptyList()); private set
    var cursor by mutableStateOf<String?>(null); private set
    var loading by mutableStateOf(false); private set
    var loaded by mutableStateOf(false); private set

    suspend fun first() {
        loading = true
        try {
            val p = fetch(null)
            items = p.items.distinctBy { it.id }
            cursor = p.nextCursor
            loaded = true
        } finally {
            loading = false
        }
    }

    suspend fun more() {
        val cur = cursor ?: return
        if (loading) return
        loading = true
        try {
            val p = fetch(cur)
            items = (items + p.items).distinctBy { it.id }
            cursor = p.nextCursor
        } finally {
            loading = false
        }
    }

    fun patch(id: String, f: (Post) -> Post) { items = items.map { it.patched(id, f) } }
}

/** プロフィール画面の状態。戻ってきたとき、読み込み済みの中身とスクロール位置が残る */
class ProfileController(private val vm: MainViewModel, val handle: String) : ScreenController {
    var user by mutableStateOf<User?>(null); private set
    var failed by mutableStateOf(false); private set
    var tab by mutableIntStateOf(0); private set

    val posts = PagedPosts { vm.api.userPosts(handle, it) }
    val likes = PagedPosts { vm.api.userLikes(handle, it) }
    val listState = LazyListState()
    private var started = false

    fun start() {
        if (started) return
        started = true
        loadUser()
        vm.launchSafely { posts.first() }
    }

    fun loadUser() {
        vm.launchSafely(onError = { failed = true }) {
            failed = false
            user = vm.api.user(handle)
        }
    }

    fun selectTab(i: Int) {
        tab = i
        if (i == 1 && !likes.loaded && !likes.loading) vm.launchSafely { likes.first() }
    }

    fun toggleFollow() {
        val u = user ?: return
        val on = !u.following
        user = u.copy(following = on, followerCount = (u.followerCount + if (on) 1 else -1).coerceAtLeast(0))
        vm.launchSafely(onError = { user = u }) {
            if (on) vm.api.follow(handle) else vm.api.unfollow(handle)
            // 非公開アカウントはフォローリクエストになるので、実際の状態を取り直す
            user = vm.api.user(handle)
        }
    }

    override fun patch(id: String, f: (Post) -> Post) {
        posts.patch(id, f)
        likes.patch(id, f)
    }

    override fun onReplyPosted() {}
}

@Composable
fun ProfileScreen(vm: MainViewModel, loader: ImageLoader, handle: String, actions: PostActions) {
    val c = North.colors
    val ctl = vm.screen("user:$handle") { ProfileController(vm, handle) }
    val user = ctl.user

    LaunchedEffect(ctl) { ctl.start() }

    Box(Modifier.fillMaxSize().background(c.bg)) {
        if (user == null) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                if (ctl.failed) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("プロフィールを読み込めませんでした", color = c.textMuted, fontSize = 15.sp)
                        TextButton(onClick = { ctl.loadUser() }) { Text("もう一度試す", color = c.accent) }
                    }
                } else {
                    CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(28.dp))
                }
            }
        } else {
            val list = if (ctl.tab == 0) ctl.posts else ctl.likes
            val isSelf = vm.ui.me?.id == user.id || vm.ui.me?.handle.equals(user.handle, ignoreCase = true)

            LazyColumn(Modifier.fillMaxSize(), state = ctl.listState) {
                item(key = "header") {
                    ProfileHeader(
                        user, isSelf, loader,
                        onFollow = { ctl.toggleFollow() },
                        onOpenFollows = { kind -> vm.open(Dest.follows(user.handle, kind)) },
                    )
                }
                item(key = "tabs") { NorthTabs(listOf("ポスト", "いいね"), ctl.tab) { ctl.selectTab(it) } }

                items(list.items, key = { "${ctl.tab}:${it.id}" }) { PostCard(it, loader, actions) }

                if (list.cursor != null) {
                    item(key = "more") {
                        // 末尾が見えたら続きを読む
                        LaunchedEffect(list.cursor, ctl.tab) { vm.launchSafely { list.more() } }
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(color = c.accent, strokeWidth = 2.dp, modifier = Modifier.size(24.dp))
                        }
                    }
                } else if (list.loaded && list.items.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            if (user.isProtected && !isSelf && !user.following) "このアカウントのポストは非公開です"
                            else if (ctl.tab == 0) "ポストはまだありません" else "いいねはまだありません",
                            color = c.textMuted,
                            fontSize = 15.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                        )
                    }
                }
            }
        }

        // 戻るボタン（ヘッダー画像の上に重ねる）
        Box(
            Modifier
                .padding(12.dp)
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0x99000000))
                .clickable { vm.back() }
                .align(Alignment.TopStart),
            contentAlignment = Alignment.Center,
        ) { NorthIcon(NIcons.Back, Color.White, 20.dp, modifier = Modifier.size(20.dp)) }
    }
}

@Composable
private fun ProfileHeader(
    user: User,
    isSelf: Boolean,
    loader: ImageLoader,
    onFollow: () -> Unit,
    onOpenFollows: (String) -> Unit,
) {
    val c = North.colors
    val uriHandler = LocalUriHandler.current

    Column(Modifier.fillMaxWidth()) {
        // ヘッダー画像（3:1）。無いときはアクセント系の無地
        Box(Modifier.fillMaxWidth().aspectRatio(3f).background(c.elev3)) {
            val url = Config.absUrl(user.headerUrl)
            if (url != null) {
                AsyncImage(
                    model = url,
                    imageLoader = loader,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }

        // アイコン（ヘッダーに半分重ねる）とフォローボタン
        Box(Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 16.dp)) {
            Avatar(
                user, 80.dp, loader,
                Modifier
                    .align(Alignment.TopStart)
                    .offset(y = (-40).dp)
                    .requiredSize(80.dp)
                    .border(4.dp, c.bg, CircleShape),
            )
            if (!isSelf) {
                val following = user.following
                Box(
                    Modifier
                        .align(Alignment.CenterEnd)
                        .height(34.dp)
                        .clip(CircleShape)
                        .then(
                            if (following) Modifier.border(1.dp, c.borderStrong, CircleShape)
                            else Modifier.background(c.post)
                        )
                        .clickable(onClick = onFollow)
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (following) "フォロー中" else "フォローする",
                        color = if (following) c.text else c.textOnPost,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }

        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(
                    user.name,
                    color = c.text,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (user.verified) {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(c.accent), contentAlignment = Alignment.Center) {
                        Text("✓", color = c.textOnAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
                if (user.isProtected) Text("🔒", fontSize = 14.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("@${user.handle}", color = c.textMuted, fontSize = 15.sp)
                if (user.followedBy) {
                    Box(Modifier.clip(CircleShape).background(c.elev3).padding(horizontal = 8.dp, vertical = 2.dp)) {
                        Text("フォローされています", color = c.textMuted, fontSize = 12.sp)
                    }
                }
            }

            if (!user.bio.isNullOrBlank()) {
                Text(user.bio, color = c.text, fontSize = 15.sp, lineHeight = 21.sp, modifier = Modifier.padding(top = 12.dp))
            }

            val meta = buildList<String> {
                user.location?.takeIf { it.isNotBlank() }?.let { add(it) }
                joinedMonth(user.createdAt).takeIf { it.isNotEmpty() }?.let { add("${it}から利用") }
            }
            if (meta.isNotEmpty()) {
                Text(meta.joinToString("  ·  "), color = c.textMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp))
            }
            user.website?.takeIf { it.isNotBlank() }?.let { site ->
                Text(
                    site,
                    color = c.accent,
                    fontSize = 14.sp,
                    maxLines = 1,
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .clickable {
                            val url = if (site.startsWith("http://") || site.startsWith("https://")) site else "https://$site"
                            runCatching { uriHandler.openUri(url) }
                        },
                )
            }

            Row(Modifier.padding(top = 12.dp, bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                listOf(
                    Triple(user.followingCount, "フォロー中", "following"),
                    Triple(user.followerCount, "フォロワー", "followers"),
                    Triple(user.tweetCount, "ポスト", null),
                ).forEach { (n, label, destination) ->
                        Text(
                            buildAnnotatedString {
                                withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = c.text)) { append(n.toString()) }
                                append(" $label")
                            },
                            color = c.textMuted,
                            fontSize = 14.sp,
                            modifier = if (destination != null) Modifier.clickable { onOpenFollows(destination) } else Modifier,
                        )
                    }
            }
        }
    }
}
