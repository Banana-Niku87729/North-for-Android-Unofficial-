package dev.rec877.north

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import dev.rec877.north.ui.theme.NorthColors
import dev.rec877.north.ui.theme.midnightColors

data class UiState(
    val loggedIn: Boolean = false,
    val me: User? = null,
    val posts: List<Post> = emptyList(),
    val nextCursor: String? = null,
    /** true=「おすすめ」の並び / false=最新ポスト */
    val ranked: Boolean = false,
    val refreshing: Boolean = false,
    val loadingMore: Boolean = false,
    val posting: Boolean = false,
    val message: String? = null,
    /** 権限不足のエラー時に true。「再ログイン」ボタンを出す */
    val reloginHint: Boolean = false,
)

data class SearchState(
    val input: String = "",
    /** 実際に検索した語句（入力欄とは別。編集中に結果が変わらないようにする） */
    val query: String = "",
    /** latest | top */
    val tab: String = "latest",
    val searched: Boolean = false,
    val results: List<Post> = emptyList(),
    val nextCursor: String? = null,
    val loading: Boolean = false,
    val history: List<String> = emptyList(),
    /** 同じ語句を再検索した場合にも、結果リストを先頭へ戻すための世代番号 */
    val version: Int = 0,
)

data class NotifState(
    val items: List<Notification> = emptyList(),
    val nextCursor: String? = null,
    val refreshing: Boolean = false,
    val loadingMore: Boolean = false,
    val loaded: Boolean = false,
    /** 未読の数（ナビのバッジに出す） */
    val unread: Int = 0,
)

/** ポスト詳細・プロフィールのように、ホームの上に重ねる画面の状態を持つもの */
interface ScreenController {
    /** いいね・リポストなどで一覧側のポストが変わったとき、この画面の中身も揃える */
    fun patch(id: String, f: (Post) -> Post)

    /** 返信が投稿されたとき */
    fun onReplyPosted()
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val nApp = app as NorthApp
    private val http = nApp.http
    private val auth = nApp.auth
    val api: NorthApi = nApp.api

    private val apiHost = Config.API_BASE.toHttpUrl().host
    private val prefs = app.getSharedPreferences("north_prefs", Context.MODE_PRIVATE)

    /**
     * 画像・動画取得用のクライアント。APIホストへのリクエストにだけBearerを付ける
     * （非公開メディアの配信にはBearerが必要。他ホストにはトークンを送らない）。
     */
    val imageClient: OkHttpClient = http.newBuilder().addInterceptor { chain ->
        val req = chain.request()
        if (req.url.host == apiHost) {
            val token = runCatching { runBlocking { auth.accessToken() } }.getOrNull()
            if (token != null) {
                return@addInterceptor chain.proceed(
                    req.newBuilder().header("Authorization", "Bearer $token").build()
                )
            }
        }
        chain.proceed(req)
    }.build()

    var ui by mutableStateOf(UiState(loggedIn = auth.isLoggedIn()))
        private set

    var search by mutableStateOf(SearchState(history = loadHistory()))
        private set

    var notif by mutableStateOf(NotifState())
        private set

    /** スマホへのバックグラウンド通知（約15分おきの確認）を使うか */
    var bgNotif by mutableStateOf(prefs.getBoolean(K_BG_NOTIF, true))
        private set

    /** 参考サイトの「表示」設定。既定値は従来どおり midnight / yellow。 */
    var themeColors by mutableStateOf(loadThemeColors())
        private set
    var dimBackground by mutableStateOf(prefs.getBoolean(K_DIM_BG, false))
        private set

    /** ホームの上に重ねている画面。"post:ID" / "user:ユーザー名" */
    val backStack = mutableStateListOf<String>()
    private val screens = HashMap<String, ScreenController>()

    /** 通知タブを開いている間だけ true。新着イベントで一覧も取り直すかの判断に使う */
    private var notifVisible = false

    private var searchJob: Job? = null

    init {
        if (ui.loggedIn) {
            refresh()
            if (bgNotif) BackgroundNotifications.enable(app)
        }
    }

    fun authorizeUri(): Uri = auth.buildAuthorizeUri()

    fun dismissMessage() { ui = ui.copy(message = null, reloginHint = false) }

    fun onRedirect(uri: Uri) = launchSafely {
        auth.handleRedirect(uri)
        ui = ui.copy(loggedIn = true, message = null, reloginHint = false)
        if (bgNotif) BackgroundNotifications.enable(getApplication())
        refresh()
    }

    // ---------------- 画面遷移 ----------------
    fun open(dest: String) {
        if (dest.isBlank() || backStack.lastOrNull() == dest) return
        backStack.add(dest)
    }

    /** 返信ボタンから開いたとき、詳細画面の下の入力欄にカーソルを置くための印（対象ポストのID） */
    var replyFocusPostId by mutableStateOf<String?>(null)
        private set

    fun consumeReplyFocus() { replyFocusPostId = null }

    fun openPost(id: String, focusReply: Boolean = false) {
        if (id.isBlank()) return
        if (focusReply) replyFocusPostId = id
        open(Dest.post(id))
    }
    fun openUser(handle: String) { if (handle.isNotBlank()) open(Dest.user(handle)) }

    fun back() {
        backStack.removeLastOrNull()?.let { screens.remove(it) }
    }

    fun popToRoot() {
        backStack.clear()
        screens.clear()
    }

    /** 画面ごとの状態（読み込み済みの中身やスクロール位置）を、戻ってきたときのために保持する */
    @Suppress("UNCHECKED_CAST")
    fun <T : ScreenController> screen(key: String, create: () -> T): T =
        screens.getOrPut(key, create) as T

    // ---------------- スマホ通知 ----------------
    fun updateBgNotif(on: Boolean) {
        bgNotif = on
        prefs.edit().putBoolean(K_BG_NOTIF, on).apply()
        if (on) BackgroundNotifications.enable(getApplication()) else BackgroundNotifications.disable(getApplication())
    }

    /** Android 13以上: 通知の許可をまだ聞いていなければ true（聞いたことは覚えておく） */
    fun shouldAskNotifPermission(): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        if (prefs.getBoolean(K_ASKED_PERM, false)) return false
        prefs.edit().putBoolean(K_ASKED_PERM, true).apply()
        return ContextCompat.checkSelfPermission(
            getApplication(), Manifest.permission.POST_NOTIFICATIONS
        ) != PackageManager.PERMISSION_GRANTED
    }

    // ---------------- 通知（アプリ内）----------------
    /**
     * 画面が見えている間だけ呼ばれる想定（AppShell が repeatOnLifecycle(STARTED) で起動/停止）。
     * 起動時に未読数を取り直し、あとはSSEの新着イベントを待つ。
     */
    suspend fun runNotificationStream() {
        refreshUnread()
        try {
            api.notificationEvents().collect { onNotificationEvent() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: NotLoggedInException) {
            popToRoot()
            ui = UiState(loggedIn = false, message = "もう一度ログインしてください")
        } catch (e: ApiException) {
            // 権限不足(403)など。再ログインの案内を出す
            ui = ui.copy(message = e.message, reloginHint = e.isPermission)
        } catch (e: Exception) {
            // 通信エラーは黙って終了（次に画面が戻ったときに再開する）
        }
    }

    private fun onNotificationEvent() {
        refreshUnread()
        if (notifVisible) refreshNotifications(silent = true)
    }

    fun onNotifTabShown() {
        notifVisible = true
        refreshNotifications(silent = notif.loaded)
    }

    /** 通知を見終わった（別のタブへ移った・別の画面を開いた）ら、自動で既読にしてバッジを消す */
    fun onNotifTabHidden() {
        if (!notifVisible) return
        notifVisible = false
        if (notif.unread > 0 || notif.items.any { !it.read }) markReadQuietly()
    }

    private fun markReadQuietly() {
        // 見た目は先に既読にして、バッジをすぐ消す
        notif = notif.copy(items = notif.items.map { it.copy(read = true) }, unread = 0)
        viewModelScope.launch {
            try {
                api.markNotificationsRead()
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotLoggedInException) {
                popToRoot()
                ui = UiState(loggedIn = false, message = "もう一度ログインしてください")
            } catch (e: ApiException) {
                if (e.isPermission) ui = ui.copy(message = e.message, reloginHint = true)
            } catch (e: Exception) {
            }
            refreshUnread() // 実際の数に合わせ直す（失敗していたらバッジが戻る）
        }
    }

    /** 未読数だけを軽く取る。失敗しても画面は乱さない（権限不足のときだけ案内する） */
    fun refreshUnread() {
        viewModelScope.launch {
            try {
                notif = notif.copy(unread = api.unreadCount())
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotLoggedInException) {
                popToRoot()
                ui = UiState(loggedIn = false, message = "もう一度ログインしてください")
            } catch (e: ApiException) {
                if (e.isPermission) ui = ui.copy(message = e.message, reloginHint = true)
            } catch (e: Exception) {
            }
        }
    }

    fun refreshNotifications(silent: Boolean = false) = launchSafely {
        if (!silent) notif = notif.copy(refreshing = true)
        val page = api.notifications(null)
        notif = notif.copy(
            refreshing = false,
            loaded = true,
            items = page.items.distinctBy { it.id },
            nextCursor = page.nextCursor,
        )
    }

    fun loadMoreNotifications() {
        val cursor = notif.nextCursor ?: return
        if (notif.loadingMore || notif.refreshing) return
        launchSafely {
            notif = notif.copy(loadingMore = true)
            val page = api.notifications(cursor)
            notif = notif.copy(
                loadingMore = false,
                items = (notif.items + page.items).distinctBy { it.id },
                nextCursor = page.nextCursor,
            )
        }
    }

    /** 「すべて既読」ボタン */
    fun markAllRead() = launchSafely {
        api.markNotificationsRead()
        notif = notif.copy(items = notif.items.map { it.copy(read = true) }, unread = 0)
        refreshUnread() // 詳細フィルターで隠れている分は既読にならないので、実際の数を取り直す
    }

    // ---------------- ホーム ----------------
    fun refresh() = launchSafely {
        ui = ui.copy(refreshing = true, message = null, reloginHint = false)
        val me = ui.me ?: api.me()
        val page = api.homeTimeline(null, ui.ranked)
        ui = ui.copy(
            refreshing = false,
            me = me,
            posts = page.items.distinctBy { it.id },
            nextCursor = page.nextCursor,
        )
    }

    fun toggleRanked() {
        ui = ui.copy(ranked = !ui.ranked, posts = emptyList(), nextCursor = null)
        refresh()
    }

    fun loadMore() {
        val cursor = ui.nextCursor ?: return
        if (ui.loadingMore || ui.refreshing) return
        launchSafely {
            ui = ui.copy(loadingMore = true)
            val page = api.homeTimeline(cursor, ui.ranked) // nextCursorは加工せずそのまま渡す
            // LazyColumnのkeyが重複すると落ちるので、IDで重複を除く
            ui = ui.copy(
                loadingMore = false,
                posts = (ui.posts + page.items).distinctBy { it.id },
                nextCursor = page.nextCursor,
            )
        }
    }

    // ---------------- 検索 ----------------
    fun setSearchInput(v: String) { search = search.copy(input = v) }

    fun clearSearch() {
        searchJob?.cancel()
        search = search.copy(
            input = "", query = "", searched = false,
            results = emptyList(), nextCursor = null, loading = false,
        )
    }

    fun submitSearch(raw: String) {
        val q = raw.trim()
        if (q.isEmpty()) return
        val hist = (listOf(q) + search.history.filter { it != q }).take(MAX_HISTORY)
        saveHistory(hist)
        search = search.copy(
            input = q, query = q, searched = true,
            results = emptyList(), nextCursor = null, history = hist, version = search.version + 1,
        )
        runSearch(null)
    }

    fun setSearchTab(tab: String) {
        if (tab == search.tab) return
        search = search.copy(tab = tab, results = emptyList(), nextCursor = null, version = search.version + 1)
        if (search.searched) runSearch(null)
    }

    fun loadMoreSearch() {
        val cursor = search.nextCursor ?: return
        if (search.loading) return
        runSearch(cursor)
    }

    fun removeHistory(q: String) {
        val hist = search.history.filter { it != q }
        saveHistory(hist)
        search = search.copy(history = hist)
    }

    fun clearHistory() {
        saveHistory(emptyList())
        search = search.copy(history = emptyList())
    }

    fun updateAccent(argb: Long) {
        prefs.edit().putLong(K_ACCENT, argb).apply()
        themeColors = midnightColors(Color(argb), dimBackground)
    }

    fun updateDimBackground(enabled: Boolean) {
        dimBackground = enabled
        prefs.edit().putBoolean(K_DIM_BG, enabled).apply()
        themeColors = midnightColors(Color(prefs.getLong(K_ACCENT, DEFAULT_ACCENT)), enabled)
    }

    fun openSettings() = open(Dest.SETTINGS)

    private fun loadThemeColors(): NorthColors =
        midnightColors(Color(prefs.getLong(K_ACCENT, DEFAULT_ACCENT)), prefs.getBoolean(K_DIM_BG, false))

    private fun runSearch(cursor: String?) {
        searchJob?.cancel()
        val q = search.query
        val tab = search.tab
        searchJob = launchSafely(onError = { search = search.copy(loading = false) }) {
            search = search.copy(loading = true)
            val page = api.search(q, tab, cursor)
            // 検索中に語句やタブが変わっていたら、古い結果は捨てる
            if (q != search.query || tab != search.tab) return@launchSafely
            search = search.copy(
                loading = false,
                results = (if (cursor == null) page.items else search.results + page.items).distinctBy { it.id },
                nextCursor = page.nextCursor,
            )
        }
    }

    private fun loadHistory(): List<String> =
        prefs.getString(K_HISTORY, "").orEmpty().split('\n').filter { it.isNotBlank() }

    private fun saveHistory(list: List<String>) {
        prefs.edit().putString(K_HISTORY, list.joinToString("\n")).apply()
    }

    // ---------------- 投稿・リアクション ----------------
    /** 画像があれば先に1枚ずつアップロードし、そのIDを付けて投稿する */
    fun post(
        text: String,
        images: List<Uri>,
        replyToId: String? = null,
        quoteId: String? = null,
        onDone: () -> Unit = {},
    ) {
        if (ui.posting) return
        launchSafely {
            ui = ui.copy(posting = true, message = null, reloginHint = false)
            val resolver = getApplication<Application>().contentResolver
            val mediaIds = images.map { api.uploadMedia(resolver, it).id }
            api.createPost(text.trim(), mediaIds, replyToId, quoteId)
            ui = ui.copy(posting = false)
            onDone()
            if (quoteId != null) updatePost(quoteId) { it.copy(quoteCount = it.quoteCount + 1) }
            if (replyToId == null) {
                refresh()
            } else {
                updatePost(replyToId) { it.copy(replyCount = it.replyCount + 1) }
                // 開いているポスト詳細に、いま投稿した返信を反映させる
                screens.values.toList().forEach { it.onReplyPosted() }
            }
        }
    }

    fun toggleLike(p: Post) {
        val on = !p.liked
        val delta = if (on) 1 else -1
        updatePost(p.id) { it.copy(liked = on, likeCount = (it.likeCount + delta).coerceAtLeast(0)) }
        launchSafely(onError = {
            updatePost(p.id) { it.copy(liked = p.liked, likeCount = p.likeCount) }
        }) {
            if (on) api.like(p.id) else api.unlike(p.id)
        }
    }

    fun toggleRepost(p: Post) {
        val on = !p.retweeted
        val delta = if (on) 1 else -1
        updatePost(p.id) { it.copy(retweeted = on, retweetCount = (it.retweetCount + delta).coerceAtLeast(0)) }
        launchSafely(onError = {
            updatePost(p.id) { it.copy(retweeted = p.retweeted, retweetCount = p.retweetCount) }
        }) {
            if (on) api.retweet(p.id) else api.unretweet(p.id)
        }
    }

    fun logout() = launchSafely {
        auth.logout()
        BackgroundNotifications.disable(getApplication())
        searchJob?.cancel()
        popToRoot()
        ui = UiState(loggedIn = false)
        search = SearchState(history = search.history)
        notif = NotifState()
        notifVisible = false
    }

    /** ホーム・検索結果・開いている詳細/プロフィールのすべてで、該当ポストを書き換える */
    private fun updatePost(id: String, f: (Post) -> Post) {
        ui = ui.copy(posts = ui.posts.map { it.patched(id, f) })
        search = search.copy(results = search.results.map { it.patched(id, f) })
        screens.values.toList().forEach { it.patch(id, f) }
    }

    /** 画面から使えるように公開している。例外は共通のエラー表示（赤いバー）に流す */
    fun launchSafely(onError: (() -> Unit)? = null, block: suspend () -> Unit): Job =
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotLoggedInException) {
                popToRoot()
                ui = UiState(loggedIn = false, message = "もう一度ログインしてください")
            } catch (e: ApiException) {
                onError?.invoke()
                notif = notif.copy(refreshing = false, loadingMore = false)
                ui = ui.copy(
                    refreshing = false, loadingMore = false, posting = false,
                    message = e.message, reloginHint = e.isPermission,
                )
            } catch (e: Exception) {
                onError?.invoke()
                notif = notif.copy(refreshing = false, loadingMore = false)
                ui = ui.copy(
                    refreshing = false, loadingMore = false, posting = false,
                    message = e.message ?: e.toString(),
                )
            }
        }

    private companion object {
        const val K_HISTORY = "search_history"
        const val K_BG_NOTIF = "bg_notif"
        const val K_ASKED_PERM = "asked_notif_perm"
        const val K_ACCENT = "accent"
        const val K_DIM_BG = "dim_background"
        const val DEFAULT_ACCENT = 0xFFFFD400L
        const val MAX_HISTORY = 10
    }
}
