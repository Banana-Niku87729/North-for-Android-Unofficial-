package dev.rec877.north.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.rec877.north.MainViewModel
import dev.rec877.north.ui.theme.North

private data class SettingItem(val title: String, val description: String)

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val c = North.colors
    var page by remember { mutableStateOf<String?>(null) }
    if (page == "display") { DisplaySettings(vm) { page = null }; return }
    val sections = listOf(
        SettingItem("アカウント", "アカウント情報を確認・変更します"),
        SettingItem("ポストの設定", "ポストの送信に関する設定を管理します"),
        SettingItem("セキュリティとアカウントアクセス", "セキュリティとログイン履歴を管理します"),
        SettingItem("プライバシーと安全", "表示する情報と共有範囲を管理します"),
        SettingItem("通知", "受け取る通知の種類を選びます"),
        SettingItem("アクセシビリティ、表示、言語", "north の表示方法を管理します"),
        SettingItem("開発者向け", "APIキーを管理します"),
    )
    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.size(28.dp).clickable { vm.back() }, contentAlignment = Alignment.Center) { NorthIcon(NIcons.Back, c.text, 22.dp, modifier = Modifier.size(22.dp)) }
            Text("設定", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        }
        HorizontalDivider(color = c.border)
        LazyColumn(Modifier.fillMaxSize()) {
            items(sections, key = SettingItem::title) { item ->
                Row(Modifier.fillMaxWidth().clickable { if (item.title == "アクセシビリティ、表示、言語") page = "display" }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(item.title, color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text(item.description, color = c.textMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp)) }
                    Text("›", color = c.textMuted, fontSize = 24.sp)
                }
                HorizontalDivider(color = c.border)
            }
            item("resources") { Text("その他のリソース", color = c.text, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(16.dp)) }
        }
    }
}

@Composable
private fun DisplaySettings(vm: MainViewModel, onBack: () -> Unit) {
    val c = North.colors
    val accents = listOf("黄色" to 0xFFFFD400L, "青" to 0xFF1D9BF0L, "ピンク" to 0xFFF91880L)
    Column(Modifier.fillMaxSize().background(c.bg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Box(Modifier.size(28.dp).clickable(onClick = onBack), contentAlignment = Alignment.Center) { NorthIcon(NIcons.Back, c.text, 22.dp, modifier = Modifier.size(22.dp)) }
            Column { Text("アクセシビリティ、表示、言語", color = c.text, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold); Text("表示", color = c.textMuted, fontSize = 14.sp) }
        }
        HorizontalDivider(color = c.border)
        Text("色", color = c.text, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            accents.forEach { (name, argb) -> Column(horizontalAlignment = Alignment.CenterHorizontally) { Box(Modifier.size(42.dp).clip(CircleShape).background(Color(argb)).clickable { vm.updateAccent(argb) }); Text(name, color = c.textMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp)) } }
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("背景", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text("より暗い背景を使用する", color = c.textMuted, fontSize = 13.sp) }; Switch(checked = vm.dimBackground, onCheckedChange = vm::updateDimBackground) }
        HorizontalDivider(color = c.border)
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text("バックグラウンド通知", color = c.text, fontSize = 16.sp, fontWeight = FontWeight.Bold); Text("アプリを閉じている間も通知を確認します", color = c.textMuted, fontSize = 13.sp) }; Switch(checked = vm.bgNotif, onCheckedChange = vm::updateBgNotif) }
    }
}
