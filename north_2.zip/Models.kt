package dev.rec877.north

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** /2 のJSON成功応答は { "data": ... } */
@Serializable data class Envelope<T>(val data: T)

@Serializable
data class User(
    val id: String = "",
    val handle: String = "",
    val name: String = "",
    val avatarUrl: String? = null,
)

@Serializable
data class Media(
    val id: String,
    /** PHOTO / GIF / VIDEO */
    val kind: String = "PHOTO",
    val url: String,
    val thumbnailUrl: String? = null,
    val width: Int = 0,
    val height: Int = 0,
    val altText: String? = null,
    val sensitive: Boolean = false,
)

@Serializable
data class Post(
    val id: String,
    // 表示できないポストは本文などが返らないので、すべて既定値を持たせて落ちないようにする
    val text: String = "",
    val createdAt: String = "",
    val author: User = User(),
    val likeCount: Int = 0,
    val retweetCount: Int = 0,
    val replyCount: Int = 0,
    val liked: Boolean = false,
    val retweeted: Boolean = false,
    val retweetOf: Post? = null,
    val media: List<Media> = emptyList(),
    val unavailable: Boolean = false,
    val source: String? = null,
)

@Serializable data class PostPage(val items: List<Post>, val nextCursor: String? = null)

@Serializable data class CreatedPost(val id: String, val text: String = "")

// ---- OAuth（こちらは { "data": ... } で包まれない、RFC準拠のフラット形式）----
@Serializable
data class TokenResponse(
    @SerialName("access_token") val accessToken: String,
    @SerialName("refresh_token") val refreshToken: String,
    @SerialName("expires_in") val expiresIn: Int,
    val scope: String = "",
)

@Serializable data class OAuthError(val error: String)
