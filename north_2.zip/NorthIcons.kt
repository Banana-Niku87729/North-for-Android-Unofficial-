package dev.rec877.north.ui

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.addPathNodes
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Immutable
class NIcon(
    val strokes: List<String> = emptyList(),
    val fills: List<String> = emptyList(),
    val strokeWidth: Float = 1.8f,
    val viewport: Float = 24f,
    /** viewBox の左上座標（スパークルのみ -128 から始まる） */
    val origin: Float = 0f,
)

object NIcons {
    val Reply = NIcon(strokes = listOf(
        "M4 11.5c0-3.6 3.1-6.5 7-6.5h2c3.9 0 7 2.9 7 6.5S16.9 18 13 18h-1.5L7 21.2V17.4C5.2 16.2 4 14 4 11.5Z"
    ))
    val Repost = NIcon(strokes = listOf(
        "M6.5 20V7.5A2.5 2.5 0 0 1 9 5h8",
        "m14.5 2.4 3 2.6-3 2.6",
        "M17.5 4v12.5a2.5 2.5 0 0 1-2.5 2.5H7",
        "m9.5 21.6-3-2.6 3-2.6",
    ))
    val Like = NIcon(strokes = listOf(
        "M12 20.3 4.9 13.6a4.6 4.6 0 0 1 0-6.6 4.9 4.9 0 0 1 7.1.5 4.9 4.9 0 0 1 7.1-.5 4.6 4.6 0 0 1 0 6.6z"
    ))
    val Image = NIcon(strokes = listOf(
        "M6 4.5h12a2.5 2.5 0 0 1 2.5 2.5v10a2.5 2.5 0 0 1-2.5 2.5H6a2.5 2.5 0 0 1-2.5-2.5V7A2.5 2.5 0 0 1 6 4.5Z",
        "M6.9 9.5a1.6 1.6 0 1 0 3.2 0a1.6 1.6 0 1 0-3.2 0Z",
        "m4.5 17 4.6-4.6 3.4 3.4 2.6-2.6 4.4 4.4",
    ))
    val Close = NIcon(strokes = listOf("M6 6l12 12M18 6L6 18"), strokeWidth = 2.2f)
    val Sparkle = NIcon(
        fills = listOf("M0 -118 C 1.4 -24 15 -2.2 80 0 C 15 2.2 1.4 24 0 118 C -1.4 24 -15 2.2 -80 0 C -15 -2.2 -1.4 -24 0 -118 Z"),
        viewport = 256f,
        origin = -128f,
    )
}

@Composable
fun NorthIcon(
    icon: NIcon,
    tint: Color,
    size: Dp = 20.dp,
    filled: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val vector = remember(icon, tint, filled, size) {
        ImageVector.Builder(
            defaultWidth = size,
            defaultHeight = size,
            viewportWidth = icon.viewport,
            viewportHeight = icon.viewport,
        ).apply {
            if (icon.origin != 0f) addGroup(translationX = -icon.origin, translationY = -icon.origin)
            icon.strokes.forEach { d ->
                addPath(
                    pathData = addPathNodes(d),
                    fill = if (filled) SolidColor(tint) else null,
                    stroke = SolidColor(tint),
                    strokeLineWidth = icon.strokeWidth,
                    strokeLineCap = StrokeCap.Round,
                    strokeLineJoin = StrokeJoin.Round,
                )
            }
            icon.fills.forEach { d ->
                addPath(pathData = addPathNodes(d), fill = SolidColor(tint))
            }
        }.build()
    }
    Image(
        painter = rememberVectorPainter(vector),
        contentDescription = null,
        modifier = modifier,
    )
}
