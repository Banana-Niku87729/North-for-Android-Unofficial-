package dev.rec877.north.ui

import androidx.browser.customtabs.CustomTabsIntent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil3.ImageLoader
import dev.rec877.north.Config
import dev.rec877.north.Media
import dev.rec877.north.MainViewModel
import dev.rec877.north.Post
import dev.rec877.north.ui.theme.North

@Composable
fun HomeScreen(vm: MainViewModel, loader: ImageLoader) {
    val c = North.colors
    val ui = vm.ui
    val uriHandler = LocalUriHandler.current

    var replyTo by remember { mutableStateOf<Post?>(null) }
    var viewer by remember { mutableStateOf<Pair<List<Media>, Int>?>(null) }
    var menuOpen by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().background(c.bg).windowInsetsPadding(WindowInsets.safeDrawing)
    ) {
        // ---- ヘッダー（サイトの .head: 左にアバター、タイトル、右に切り替えボタン）----
        Row(
            Modifier.fillMaxWidth().height(53.dp).padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box {
                val me = ui.me
                if (me != null) {
                    Avatar(me, 32.dp, loader, Modifier.clickable { menuOpen = true })
                } else {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(c.elev3))
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    me?.let {
                        DropdownMenuItem(
                            text = { Text("${it.name}  @${it.handle}") },
                            onClick = { menuOpen = false },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text("ログアウト") },
                        onClick = { menuOpen = false; vm.logout() },
                    )
                }
            }
            Spacer(Modifier.width(12.dp))
            Text(
                if (ui.ranked) "おすすめ" else "最新ポスト",
                color = c.text,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                modifier = Modifier.weight(1f),
            )
            // 「最新ポスト」⇄「おすすめ」の切り替え（サイトの✦ボタン）
            Box(
                Modifier.size(40.dp).clip(CircleShape).clickable { vm.toggleRanked() },
                contentAlignment = Alignment.Center,
            ) {
                NorthIcon(
                    NIcons.Sparkle,
                    if (ui.ranked) c.accent else c.textMuted,
                    20.dp,
                    modifier = Modifier.size(20.dp),
                )
            }
        }
        HorizontalDivider(color = c.border)

        ui.message?.let { msg ->
            Text(
                msg,
                color = c.danger,
                fontSize = 14.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(c.elev2)
                    .clickable { vm.dismissMessage() }
                    .padding(horizontal = 16.dp, vertical = 10.dp),
            )
        }

        PullToRefreshBox(
            isRefreshing = ui.refreshing,
            onRefresh = { vm.refresh() },
            modifier = Modifier.weight(1f).fillMaxWidth(),
        ) {
            LazyColumn(Modifier.fillMaxSize()) {
                item(key = "composer") {
                    Composer(
                        me = ui.me,
                        loader = loader,
                        posting = ui.posting,
                        onSubmit = { text, images, onDone -> vm.post(text, images, null, onDone) },
                    )
                }

                items(ui.posts, key = { it.id }) { post ->
                    PostCard(
                        post = post,
                        loader = loader,
                        onReply = { replyTo = it },
                        onLike = { vm.toggleLike(it) },
                        onRepost = { vm.toggleRepost(it) },
                        onOpenMedia = { list, i ->
                            val m = list[i]
                            if (m.kind == "VIDEO") {
                                // 動画アプリ内再生は未対応: ブラウザで開く
                                Config.absUrl(m.url)?.let { uriHandler.openUri(it) }
                            } else {
                                val photos = list.filter { it.kind != "VIDEO" }
                                viewer = photos to photos.indexOf(m).coerceAtLeast(0)
                            }
                        },
                    )
                }

                if (ui.nextCursor != null) {
                    item(key = "more") {
                        // 末尾が見えたら次ページを読む
                        LaunchedEffect(ui.nextCursor) { vm.loadMore() }
                        Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(
                                color = c.accent,
                                strokeWidth = 2.dp,
                                modifier = Modifier.size(24.dp),
                            )
                        }
                    }
                } else if (!ui.refreshing && ui.posts.isEmpty()) {
                    item(key = "empty") {
                        Text(
                            "ポストがありません",
                            color = c.textMuted,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(32.dp),
                        )
                    }
                }
            }
        }
    }

    replyTo?.let { target ->
        ReplyDialog(
            target = target,
            posting = ui.posting,
            onDismiss = { replyTo = null },
            onSend = { text -> vm.post(text, emptyList(), target.id) { replyTo = null } },
        )
    }

    viewer?.let { (list, index) ->
        MediaViewer(list, index, loader) { viewer = null }
    }
}

@Composable
private fun ReplyDialog(target: Post, posting: Boolean, onDismiss: () -> Unit, onSend: (String) -> Unit) {
    val c = North.colors
    var text by remember { mutableStateOf("") }
    val weight = postWeight(text)
    val canSend = !posting && text.isNotBlank() && weight <= 280

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.elev1,
        title = { Text("@${target.author.handle} に返信", color = c.text, fontSize = 17.sp) },
        text = {
            Column {
                Text(target.text, color = c.textMuted, fontSize = 14.sp, maxLines = 3)
                Spacer(Modifier.height(12.dp))
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    textStyle = TextStyle(color = c.text, fontSize = 18.sp, lineHeight = 24.sp),
                    cursorBrush = SolidColor(c.accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box {
                            if (text.isEmpty()) Text("返信をポスト", color = c.textMuted, fontSize = 18.sp)
                            inner()
                        }
                    },
                )
                Text(
                    "$weight/280",
                    color = if (weight > 280) c.danger else c.textMuted,
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.End).padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onSend(text) }, enabled = canSend) {
                Text(if (posting) "送信中…" else "返信する", color = if (canSend) c.accent else c.textFaint)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("キャンセル", color = c.textMuted) } },
    )
}

@Composable
fun LoginScreen(vm: MainViewModel) {
    val c = North.colors
    val ctx = LocalContext.current
    Column(
        Modifier.fillMaxSize().background(c.bg).windowInsetsPadding(WindowInsets.safeDrawing).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("north", color = c.accent, fontSize = 48.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(8.dp))
        Text("northのアカウントでログインします", color = c.textMuted, fontSize = 15.sp)
        Spacer(Modifier.height(32.dp))
        Box(
            Modifier
                .height(48.dp)
                .clip(CircleShape)
                .background(c.post)
                .clickable { CustomTabsIntent.Builder().build().launchUrl(ctx, vm.authorizeUri()) }
                .padding(horizontal = 32.dp),
            contentAlignment = Alignment.Center,
        ) {
            Text("northでログイン", color = c.textOnPost, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }
        vm.ui.message?.let {
            Spacer(Modifier.height(24.dp))
            Text(it, color = c.danger, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}
