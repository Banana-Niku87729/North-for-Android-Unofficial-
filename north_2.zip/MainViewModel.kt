package dev.rec877.north

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient

data class UiState(
    val loggedIn: Boolean = false,
    val me: User? = null,
    val posts: List<Post> = emptyList(),
    val nextCursor: String? = null,
    /** true=「おすすめ」の並び / false=最新ポスト */
    val ranked: Boolean = false,
    val refreshing: Boolean = false,
    val loadingMore: Boolean = false,
    val posting: Boolean = false,
    val message: String? = null,
)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val http = OkHttpClient()
    private val auth = AuthRepository(SecretStore(app), http)
    private val api = NorthApi(auth, http)
    private val apiHost = Config.API_BASE.toHttpUrl().host

    /**
     * 画像取得用のクライアント。APIホストへのリクエストにだけBearerを付ける
     * （非公開メディアの配信にはBearerが必要。他ホストにはトークンを送らない）。
     */
    val imageClient: OkHttpClient = http.newBuilder().addInterceptor { chain ->
        val req = chain.request()
        if (req.url.host == apiHost) {
            val token = runCatching { runBlocking { auth.accessToken() } }.getOrNull()
            if (token != null) {
                return@addInterceptor chain.proceed(
                    req.newBuilder().header("Authorization", "Bearer $token").build()
                )
            }
        }
        chain.proceed(req)
    }.build()

    var ui by mutableStateOf(UiState(loggedIn = auth.isLoggedIn()))
        private set

    init { if (ui.loggedIn) refresh() }

    fun authorizeUri(): Uri = auth.buildAuthorizeUri()

    fun dismissMessage() { ui = ui.copy(message = null) }

    fun onRedirect(uri: Uri) = launchSafely {
        auth.handleRedirect(uri)
        ui = ui.copy(loggedIn = true, message = null)
        refresh()
    }

    fun refresh() = launchSafely {
        ui = ui.copy(refreshing = true, message = null)
        val me = ui.me ?: api.me()
        val page = api.homeTimeline(null, ui.ranked)
        ui = ui.copy(
            refreshing = false,
            me = me,
            posts = page.items.distinctBy { it.id },
            nextCursor = page.nextCursor,
        )
    }

    fun toggleRanked() {
        ui = ui.copy(ranked = !ui.ranked, posts = emptyList(), nextCursor = null)
        refresh()
    }

    fun loadMore() {
        val cursor = ui.nextCursor ?: return
        if (ui.loadingMore || ui.refreshing) return
        launchSafely {
            ui = ui.copy(loadingMore = true)
            val page = api.homeTimeline(cursor, ui.ranked) // nextCursorは加工せずそのまま渡す
            // LazyColumnのkeyが重複すると落ちるので、IDで重複を除く
            ui = ui.copy(
                loadingMore = false,
                posts = (ui.posts + page.items).distinctBy { it.id },
                nextCursor = page.nextCursor,
            )
        }
    }

    /** 画像があれば先に1枚ずつアップロードし、そのIDを付けて投稿する */
    fun post(text: String, images: List<Uri>, replyToId: String? = null, onDone: () -> Unit = {}) {
        if (ui.posting) return
        launchSafely {
            ui = ui.copy(posting = true, message = null)
            val resolver = getApplication<Application>().contentResolver
            val mediaIds = images.map { api.uploadMedia(resolver, it).id }
            api.createPost(text.trim(), mediaIds, replyToId)
            ui = ui.copy(posting = false)
            onDone()
            if (replyToId == null) refresh()
            else updatePost(replyToId) { it.copy(replyCount = it.replyCount + 1) }
        }
    }

    fun toggleLike(p: Post) {
        val on = !p.liked
        val delta = if (on) 1 else -1
        updatePost(p.id) { it.copy(liked = on, likeCount = (it.likeCount + delta).coerceAtLeast(0)) }
        launchSafely(onError = {
            updatePost(p.id) { it.copy(liked = p.liked, likeCount = p.likeCount) }
        }) {
            if (on) api.like(p.id) else api.unlike(p.id)
        }
    }

    fun toggleRepost(p: Post) {
        val on = !p.retweeted
        val delta = if (on) 1 else -1
        updatePost(p.id) { it.copy(retweeted = on, retweetCount = (it.retweetCount + delta).coerceAtLeast(0)) }
        launchSafely(onError = {
            updatePost(p.id) { it.copy(retweeted = p.retweeted, retweetCount = p.retweetCount) }
        }) {
            if (on) api.retweet(p.id) else api.unretweet(p.id)
        }
    }

    fun logout() = launchSafely {
        auth.logout()
        ui = UiState(loggedIn = false)
    }

    /** 一覧の中の該当ポスト（リポストの元ポストも含む）を書き換える */
    private fun updatePost(id: String, f: (Post) -> Post) {
        ui = ui.copy(posts = ui.posts.map { p ->
            val rt = p.retweetOf
            when {
                p.id == id -> f(p)
                rt != null && rt.id == id -> p.copy(retweetOf = f(rt))
                else -> p
            }
        })
    }

    private fun launchSafely(onError: (() -> Unit)? = null, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: NotLoggedInException) {
                ui = UiState(loggedIn = false, message = "もう一度ログインしてください")
            } catch (e: Exception) {
                onError?.invoke()
                ui = ui.copy(
                    refreshing = false,
                    loadingMore = false,
                    posting = false,
                    message = e.message ?: e.toString(),
                )
            }
        }
    }
}
