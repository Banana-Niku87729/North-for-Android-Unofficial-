package dev.rec877.north

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.putJsonObject
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.UUID

/** サーバーの { "errors": [{ "message": ... }] } があればその文言、無ければ HTTPステータス */
private fun errorMessage(status: Int, body: String): String =
    runCatching {
        Json.parseToJsonElement(body).jsonObject["errors"]?.jsonArray
            ?.firstOrNull()?.jsonObject?.get("message")?.jsonPrimitive?.content
    }.getOrNull() ?: "HTTP $status"

class ApiException(val status: Int, val body: String) : Exception(errorMessage(status, body))

class NorthApi(private val auth: AuthRepository, private val http: OkHttpClient) {
    private val json = Json { ignoreUnknownKeys = true }
    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val bodyMethods = setOf("POST", "PUT", "PATCH")

    private class Resp(val code: Int, val text: String)

    private suspend fun send(
        method: String,
        path: String,
        body: String? = null,
        idempotent: Boolean = false,
        multipart: RequestBody? = null,
        extraHeaders: Map<String, String> = emptyMap(),
    ): String = withContext(Dispatchers.IO) {
        val key = if (idempotent) UUID.randomUUID().toString() else null

        fun exec(token: String): Resp {
            val reqBody: RequestBody? = multipart
                ?: body?.toRequestBody(jsonMedia)
                ?: if (method in bodyMethods) "".toRequestBody(null) else null
            val req = Request.Builder()
                .url(Config.API_BASE + path)
                .header("Authorization", "Bearer $token")
                .apply {
                    if (key != null) header("Idempotency-Key", key)
                    extraHeaders.forEach { (k, v) -> header(k, v) }
                }
                .method(method, reqBody)
                .build()
            return http.newCall(req).execute().use { Resp(it.code, it.body?.string().orEmpty()) }
        }

        var token = auth.accessToken()
        var r = exec(token)
        if (r.code == 401) { // 失効していたら1回だけ更新して再試行（同じIdempotency-Keyで安全に）
            token = auth.refreshAfter(token)
            r = exec(token)
        }
        if (r.code !in 200..299) throw ApiException(r.code, r.text)
        r.text
    }

    suspend fun me(): User =
        json.decodeFromString<Envelope<User>>(send("GET", "/2/users/me")).data

    /** ranked=true で「おすすめ」の並び。cursorは加工せずそのまま渡す */
    suspend fun homeTimeline(cursor: String? = null, ranked: Boolean = false): PostPage {
        val params = buildList {
            if (ranked) add("ranked=1")
            if (cursor != null) add("cursor=" + URLEncoder.encode(cursor, "UTF-8"))
        }
        val q = if (params.isEmpty()) "" else "?" + params.joinToString("&")
        return json.decodeFromString<Envelope<PostPage>>(send("GET", "/2/timelines/home$q")).data
    }

    suspend fun createPost(
        text: String,
        mediaIds: List<String> = emptyList(),
        replyToId: String? = null,
    ): CreatedPost {
        val body = buildJsonObject {
            put("text", text)
            if (mediaIds.isNotEmpty()) {
                putJsonObject("media") { putJsonArray("media_ids") { mediaIds.forEach { add(it) } } }
            }
            if (replyToId != null) {
                putJsonObject("reply") { put("in_reply_to_tweet_id", replyToId) }
            }
        }.toString()
        return json.decodeFromString<Envelope<CreatedPost>>(
            send("POST", "/2/tweets", body, idempotent = true)
        ).data
    }

    /** 画像を1枚アップロードして Media を返す（返ったidを createPost の mediaIds に渡す） */
    suspend fun uploadMedia(resolver: ContentResolver, uri: Uri): Media {
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        val name = resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0) else null } ?: "image"
        val bytes = withContext(Dispatchers.IO) {
            resolver.openInputStream(uri)?.use { it.readBytes() }
        } ?: throw IOException("画像を読み込めませんでした")

        val form = MultipartBody.Builder()
            .setType(MultipartBody.FORM)
            .addFormDataPart("file", name, bytes.toRequestBody(mime.toMediaType()))
            .build()
        val text = send(
            "POST", "/2/media/upload",
            multipart = form,
            extraHeaders = mapOf("X-North-Media-Purpose" to "posts"),
        )
        // OAuthは { "data": {...} } で包まれる。念のため包まれていない形も受ける
        return runCatching { json.decodeFromString<Envelope<Media>>(text).data }
            .getOrElse { json.decodeFromString<Media>(text) }
    }

    suspend fun like(id: String) { send("POST", "/2/tweets/$id/like", idempotent = true) }
    suspend fun unlike(id: String) { send("DELETE", "/2/tweets/$id/like") }
    suspend fun retweet(id: String) { send("POST", "/2/tweets/$id/retweet", idempotent = true) }
    suspend fun unretweet(id: String) { send("DELETE", "/2/tweets/$id/retweet") }
}
