package dev.rec877.north

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.remember
import coil3.ImageLoader
import coil3.network.okhttp.OkHttpNetworkFetcherFactory
import dev.rec877.north.ui.HomeScreen
import dev.rec877.north.ui.LoginScreen
import dev.rec877.north.ui.theme.NorthTheme

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // アプリは常にダークなので、ステータス/ナビゲーションバーのアイコンは明るい色に固定
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        // 画面回転などの再生成では、同じredirectを二重処理しない
        if (savedInstanceState == null) handleRedirect(intent)

        setContent {
            NorthTheme {
                // Bearer付きのOkHttpで画像を取得するローダー
                val loader = remember {
                    ImageLoader.Builder(applicationContext)
                        .components { add(OkHttpNetworkFetcherFactory(callFactory = { vm.imageClient })) }
                        .build()
                }
                if (vm.ui.loggedIn) HomeScreen(vm, loader) else LoginScreen(vm)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleRedirect(intent)
    }

    private fun handleRedirect(i: Intent?) {
        val uri = i?.data ?: return
        if (uri.scheme == Config.APP_SCHEME) vm.onRedirect(uri)
    }
}
