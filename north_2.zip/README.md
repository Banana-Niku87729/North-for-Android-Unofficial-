# north Android クライアント v2（画像投稿 + サイト風デザイン）

前回のプロジェクトに **上書き/追加** するファイルだけを入れています。
`app/src/main/` 以下を、同じパスにコピーしてください。

## 変更・追加ファイル
| パス | 内容 |
|---|---|
| `app/build.gradle.kts` | Coil（画像表示）を追加 |
| `AndroidManifest.xml` | テーマをダーク系に（起動時の白フラッシュ対策） |
| `java/dev/rec877/north/Config.kt` | `media.write` スコープ追加、相対URL解決 |
| `.../Models.kt` | `Media` 追加、表示不可ポスト対策の既定値 |
| `.../NorthApi.kt` | 画像アップロード、リポスト、おすすめ切替 |
| `.../MainViewModel.kt` | 投稿(画像付き)・いいね/リポスト・Bearer付き画像クライアント |
| `.../MainActivity.kt` | 上書き |
| `.../ui/theme/Theme.kt` | **テンプレートのTheme.ktを上書き**（midnight + yellow） |
| `.../ui/*.kt` | NorthIcons / Format / MediaGrid / PostCard / Composer / HomeScreen（新規） |

`ui/theme/Color.kt` と `Type.kt` はもう使わないので削除して構いません。

## 手順
1. 上のファイルを上書き/追加し、Gradle Sync
2. `Config.kt` の `CLIENT_ID` / `REDIRECT_URI` は前回の値に戻す（上書きで初期値に戻ります）
3. **一度ログアウトして、再ログイン**（`media.write` を許可し直す必要があります）
